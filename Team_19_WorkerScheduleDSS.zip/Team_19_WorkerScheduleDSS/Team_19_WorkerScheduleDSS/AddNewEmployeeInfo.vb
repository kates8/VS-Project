﻿Public Class frmKNSAddNewEmploy

End Class