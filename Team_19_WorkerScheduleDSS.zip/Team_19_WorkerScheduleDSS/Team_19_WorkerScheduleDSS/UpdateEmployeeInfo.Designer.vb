﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSUpdateEmployInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSUpdateEmployInfo))
        Me.lblKNSUEITitle = New System.Windows.Forms.Label()
        Me.btnKNSUEICancel = New System.Windows.Forms.Button()
        Me.btnKNSUEIAccept = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblKNSUEITitle
        '
        Me.lblKNSUEITitle.AutoSize = True
        Me.lblKNSUEITitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSUEITitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSUEITitle.Location = New System.Drawing.Point(513, 64)
        Me.lblKNSUEITitle.Name = "lblKNSUEITitle"
        Me.lblKNSUEITitle.Size = New System.Drawing.Size(1676, 116)
        Me.lblKNSUEITitle.TabIndex = 0
        Me.lblKNSUEITitle.Text = "Update Employee Information"
        '
        'btnKNSUEICancel
        '
        Me.btnKNSUEICancel.BackColor = System.Drawing.Color.Black
        Me.btnKNSUEICancel.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSUEICancel.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSUEICancel.Location = New System.Drawing.Point(2150, 807)
        Me.btnKNSUEICancel.Name = "btnKNSUEICancel"
        Me.btnKNSUEICancel.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSUEICancel.TabIndex = 12
        Me.btnKNSUEICancel.Text = "Cancel"
        Me.btnKNSUEICancel.UseVisualStyleBackColor = False
        '
        'btnKNSUEIAccept
        '
        Me.btnKNSUEIAccept.BackColor = System.Drawing.Color.Black
        Me.btnKNSUEIAccept.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSUEIAccept.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSUEIAccept.Location = New System.Drawing.Point(2150, 1024)
        Me.btnKNSUEIAccept.Name = "btnKNSUEIAccept"
        Me.btnKNSUEIAccept.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSUEIAccept.TabIndex = 11
        Me.btnKNSUEIAccept.Text = "Accept"
        Me.btnKNSUEIAccept.UseVisualStyleBackColor = False
        '
        'frmKNSUpdateEmployInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2664, 1267)
        Me.Controls.Add(Me.btnKNSUEICancel)
        Me.Controls.Add(Me.btnKNSUEIAccept)
        Me.Controls.Add(Me.lblKNSUEITitle)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "frmKNSUpdateEmployInfo"
        Me.Text = "Update Employee Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSUEITitle As Label
    Friend WithEvents btnKNSUEICancel As Button
    Friend WithEvents btnKNSUEIAccept As Button
End Class
