﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSContact
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSContact))
        Me.pbxKNSKPic = New System.Windows.Forms.PictureBox()
        Me.pbxKNSCPic = New System.Windows.Forms.PictureBox()
        Me.pbxKNSZPic = New System.Windows.Forms.PictureBox()
        Me.pbxKNSBPic = New System.Windows.Forms.PictureBox()
        Me.lblKNSMeetGroup = New System.Windows.Forms.Label()
        Me.lblKNSKateName = New System.Windows.Forms.Label()
        Me.lblKNSKateEmail = New System.Windows.Forms.Label()
        Me.lblKNSChrisName = New System.Windows.Forms.Label()
        Me.lblKNSChrisEmail = New System.Windows.Forms.Label()
        Me.lblKNSZeusName = New System.Windows.Forms.Label()
        Me.lblKNSZeusEmail = New System.Windows.Forms.Label()
        Me.lblKNSBotaoName = New System.Windows.Forms.Label()
        Me.lblKNSBotaoEmail = New System.Windows.Forms.Label()
        CType(Me.pbxKNSKPic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxKNSCPic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxKNSZPic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxKNSBPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbxKNSKPic
        '
        Me.pbxKNSKPic.BackgroundImage = CType(resources.GetObject("pbxKNSKPic.BackgroundImage"), System.Drawing.Image)
        Me.pbxKNSKPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pbxKNSKPic.Location = New System.Drawing.Point(117, 204)
        Me.pbxKNSKPic.Name = "pbxKNSKPic"
        Me.pbxKNSKPic.Size = New System.Drawing.Size(446, 504)
        Me.pbxKNSKPic.TabIndex = 0
        Me.pbxKNSKPic.TabStop = False
        '
        'pbxKNSCPic
        '
        Me.pbxKNSCPic.BackgroundImage = CType(resources.GetObject("pbxKNSCPic.BackgroundImage"), System.Drawing.Image)
        Me.pbxKNSCPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbxKNSCPic.Location = New System.Drawing.Point(663, 204)
        Me.pbxKNSCPic.Name = "pbxKNSCPic"
        Me.pbxKNSCPic.Size = New System.Drawing.Size(446, 504)
        Me.pbxKNSCPic.TabIndex = 1
        Me.pbxKNSCPic.TabStop = False
        '
        'pbxKNSZPic
        '
        Me.pbxKNSZPic.BackgroundImage = CType(resources.GetObject("pbxKNSZPic.BackgroundImage"), System.Drawing.Image)
        Me.pbxKNSZPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbxKNSZPic.Location = New System.Drawing.Point(1267, 204)
        Me.pbxKNSZPic.Name = "pbxKNSZPic"
        Me.pbxKNSZPic.Size = New System.Drawing.Size(446, 504)
        Me.pbxKNSZPic.TabIndex = 2
        Me.pbxKNSZPic.TabStop = False
        '
        'pbxKNSBPic
        '
        Me.pbxKNSBPic.BackgroundImage = CType(resources.GetObject("pbxKNSBPic.BackgroundImage"), System.Drawing.Image)
        Me.pbxKNSBPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbxKNSBPic.Location = New System.Drawing.Point(1847, 204)
        Me.pbxKNSBPic.Name = "pbxKNSBPic"
        Me.pbxKNSBPic.Size = New System.Drawing.Size(446, 504)
        Me.pbxKNSBPic.TabIndex = 3
        Me.pbxKNSBPic.TabStop = False
        '
        'lblKNSMeetGroup
        '
        Me.lblKNSMeetGroup.AutoSize = True
        Me.lblKNSMeetGroup.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSMeetGroup.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSMeetGroup.Location = New System.Drawing.Point(757, 26)
        Me.lblKNSMeetGroup.Name = "lblKNSMeetGroup"
        Me.lblKNSMeetGroup.Size = New System.Drawing.Size(889, 116)
        Me.lblKNSMeetGroup.TabIndex = 4
        Me.lblKNSMeetGroup.Text = "Meet the Team!"
        '
        'lblKNSKateName
        '
        Me.lblKNSKateName.AutoSize = True
        Me.lblKNSKateName.BackColor = System.Drawing.Color.Black
        Me.lblKNSKateName.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSKateName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSKateName.Location = New System.Drawing.Point(106, 756)
        Me.lblKNSKateName.Name = "lblKNSKateName"
        Me.lblKNSKateName.Size = New System.Drawing.Size(412, 65)
        Me.lblKNSKateName.TabIndex = 5
        Me.lblKNSKateName.Text = "Kate Stufano"
        '
        'lblKNSKateEmail
        '
        Me.lblKNSKateEmail.AutoSize = True
        Me.lblKNSKateEmail.BackColor = System.Drawing.Color.Black
        Me.lblKNSKateEmail.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSKateEmail.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSKateEmail.Location = New System.Drawing.Point(108, 857)
        Me.lblKNSKateEmail.Name = "lblKNSKateEmail"
        Me.lblKNSKateEmail.Size = New System.Drawing.Size(382, 52)
        Me.lblKNSKateEmail.TabIndex = 6
        Me.lblKNSKateEmail.Text = "kates8@vt.edu"
        '
        'lblKNSChrisName
        '
        Me.lblKNSChrisName.AutoSize = True
        Me.lblKNSChrisName.BackColor = System.Drawing.Color.Black
        Me.lblKNSChrisName.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSChrisName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSChrisName.Location = New System.Drawing.Point(678, 756)
        Me.lblKNSChrisName.Name = "lblKNSChrisName"
        Me.lblKNSChrisName.Size = New System.Drawing.Size(362, 65)
        Me.lblKNSChrisName.TabIndex = 7
        Me.lblKNSChrisName.Text = "Chris Stock"
        '
        'lblKNSChrisEmail
        '
        Me.lblKNSChrisEmail.AutoSize = True
        Me.lblKNSChrisEmail.BackColor = System.Drawing.Color.Black
        Me.lblKNSChrisEmail.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSChrisEmail.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSChrisEmail.Location = New System.Drawing.Point(680, 857)
        Me.lblKNSChrisEmail.Name = "lblKNSChrisEmail"
        Me.lblKNSChrisEmail.Size = New System.Drawing.Size(429, 52)
        Me.lblKNSChrisEmail.TabIndex = 8
        Me.lblKNSChrisEmail.Text = "ccstock1@vt.edu"
        '
        'lblKNSZeusName
        '
        Me.lblKNSZeusName.AutoSize = True
        Me.lblKNSZeusName.BackColor = System.Drawing.Color.Black
        Me.lblKNSZeusName.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSZeusName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSZeusName.Location = New System.Drawing.Point(1256, 756)
        Me.lblKNSZeusName.Name = "lblKNSZeusName"
        Me.lblKNSZeusName.Size = New System.Drawing.Size(490, 65)
        Me.lblKNSZeusName.TabIndex = 9
        Me.lblKNSZeusName.Text = "Zeus Temesgen"
        '
        'lblKNSZeusEmail
        '
        Me.lblKNSZeusEmail.AutoSize = True
        Me.lblKNSZeusEmail.BackColor = System.Drawing.Color.Black
        Me.lblKNSZeusEmail.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSZeusEmail.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSZeusEmail.Location = New System.Drawing.Point(1258, 857)
        Me.lblKNSZeusEmail.Name = "lblKNSZeusEmail"
        Me.lblKNSZeusEmail.Size = New System.Drawing.Size(350, 52)
        Me.lblKNSZeusEmail.TabIndex = 10
        Me.lblKNSZeusEmail.Text = "zeust@vt.edu"
        '
        'lblKNSBotaoName
        '
        Me.lblKNSBotaoName.AutoSize = True
        Me.lblKNSBotaoName.BackColor = System.Drawing.Color.Black
        Me.lblKNSBotaoName.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSBotaoName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSBotaoName.Location = New System.Drawing.Point(1836, 756)
        Me.lblKNSBotaoName.Name = "lblKNSBotaoName"
        Me.lblKNSBotaoName.Size = New System.Drawing.Size(386, 65)
        Me.lblKNSBotaoName.TabIndex = 11
        Me.lblKNSBotaoName.Text = "Botao Xiong"
        '
        'lblKNSBotaoEmail
        '
        Me.lblKNSBotaoEmail.AutoSize = True
        Me.lblKNSBotaoEmail.BackColor = System.Drawing.Color.Black
        Me.lblKNSBotaoEmail.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSBotaoEmail.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSBotaoEmail.Location = New System.Drawing.Point(1838, 857)
        Me.lblKNSBotaoEmail.Name = "lblKNSBotaoEmail"
        Me.lblKNSBotaoEmail.Size = New System.Drawing.Size(448, 52)
        Me.lblKNSBotaoEmail.TabIndex = 12
        Me.lblKNSBotaoEmail.Text = "botaox95@vt.edu"
        '
        'frmKNSContact
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2460, 1186)
        Me.Controls.Add(Me.lblKNSBotaoEmail)
        Me.Controls.Add(Me.lblKNSBotaoName)
        Me.Controls.Add(Me.lblKNSZeusEmail)
        Me.Controls.Add(Me.lblKNSZeusName)
        Me.Controls.Add(Me.lblKNSChrisEmail)
        Me.Controls.Add(Me.lblKNSChrisName)
        Me.Controls.Add(Me.lblKNSKateEmail)
        Me.Controls.Add(Me.lblKNSKateName)
        Me.Controls.Add(Me.lblKNSMeetGroup)
        Me.Controls.Add(Me.pbxKNSBPic)
        Me.Controls.Add(Me.pbxKNSZPic)
        Me.Controls.Add(Me.pbxKNSCPic)
        Me.Controls.Add(Me.pbxKNSKPic)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "frmKNSContact"
        Me.Text = "Contact Info"
        CType(Me.pbxKNSKPic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxKNSCPic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxKNSZPic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxKNSBPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pbxKNSKPic As PictureBox
    Friend WithEvents pbxKNSCPic As PictureBox
    Friend WithEvents pbxKNSZPic As PictureBox
    Friend WithEvents pbxKNSBPic As PictureBox
    Friend WithEvents lblKNSMeetGroup As Label
    Friend WithEvents lblKNSKateName As Label
    Friend WithEvents lblKNSKateEmail As Label
    Friend WithEvents lblKNSChrisName As Label
    Friend WithEvents lblKNSChrisEmail As Label
    Friend WithEvents lblKNSZeusName As Label
    Friend WithEvents lblKNSZeusEmail As Label
    Friend WithEvents lblKNSBotaoName As Label
    Friend WithEvents lblKNSBotaoEmail As Label
End Class
