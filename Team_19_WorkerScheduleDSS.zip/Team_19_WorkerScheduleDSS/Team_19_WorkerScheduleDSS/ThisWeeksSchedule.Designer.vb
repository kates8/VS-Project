﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSThisWeeksSchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSThisWeeksSchedule))
        Me.lblKNSTWSTitle = New System.Windows.Forms.Label()
        Me.btnKNSTWSDone = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblKNSTWSTitle
        '
        Me.lblKNSTWSTitle.AutoSize = True
        Me.lblKNSTWSTitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSTWSTitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSTWSTitle.Location = New System.Drawing.Point(769, 36)
        Me.lblKNSTWSTitle.Name = "lblKNSTWSTitle"
        Me.lblKNSTWSTitle.Size = New System.Drawing.Size(1216, 116)
        Me.lblKNSTWSTitle.TabIndex = 75
        Me.lblKNSTWSTitle.Text = "This Week's Schedule"
        '
        'btnKNSTWSDone
        '
        Me.btnKNSTWSDone.BackColor = System.Drawing.Color.Black
        Me.btnKNSTWSDone.Location = New System.Drawing.Point(2229, 1038)
        Me.btnKNSTWSDone.Name = "btnKNSTWSDone"
        Me.btnKNSTWSDone.Size = New System.Drawing.Size(358, 136)
        Me.btnKNSTWSDone.TabIndex = 76
        Me.btnKNSTWSDone.Text = "Done"
        Me.btnKNSTWSDone.UseVisualStyleBackColor = False
        '
        'frmKNSThisWeeksSchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2658, 1249)
        Me.Controls.Add(Me.btnKNSTWSDone)
        Me.Controls.Add(Me.lblKNSTWSTitle)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "frmKNSThisWeeksSchedule"
        Me.Text = "This Week's Schedule"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSTWSTitle As Label
    Friend WithEvents btnKNSTWSDone As Button
End Class
