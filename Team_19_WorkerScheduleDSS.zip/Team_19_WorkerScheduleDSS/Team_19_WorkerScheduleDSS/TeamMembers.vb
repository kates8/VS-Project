﻿Public Class frmKNSContact
    Private Sub lblKNSBotaoEmail_Click(sender As Object, e As EventArgs) Handles lblKNSBotaoEmail.Click

    End Sub
End Class