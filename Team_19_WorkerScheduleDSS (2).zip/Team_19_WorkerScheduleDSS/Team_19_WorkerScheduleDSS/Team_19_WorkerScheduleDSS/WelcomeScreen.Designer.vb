﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSWelcome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSWelcome))
        Me.lblKNSWelcome = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblKNSUsername = New System.Windows.Forms.Label()
        Me.lblKNSPassword = New System.Windows.Forms.Label()
        Me.tbxKNSUsername = New System.Windows.Forms.TextBox()
        Me.txbKNSPassword = New System.Windows.Forms.TextBox()
        Me.bntKNSSubmit = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblKNSWelcome
        '
        Me.lblKNSWelcome.AutoSize = True
        Me.lblKNSWelcome.BackColor = System.Drawing.Color.Black
        Me.lblKNSWelcome.Font = New System.Drawing.Font("Verdana", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSWelcome.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSWelcome.Location = New System.Drawing.Point(877, -10)
        Me.lblKNSWelcome.Name = "lblKNSWelcome"
        Me.lblKNSWelcome.Size = New System.Drawing.Size(1183, 233)
        Me.lblKNSWelcome.TabIndex = 0
        Me.lblKNSWelcome.Text = "WELCOME"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(730, 258)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(0, 0)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'lblKNSUsername
        '
        Me.lblKNSUsername.AutoSize = True
        Me.lblKNSUsername.BackColor = System.Drawing.Color.Black
        Me.lblKNSUsername.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSUsername.ForeColor = System.Drawing.Color.White
        Me.lblKNSUsername.Location = New System.Drawing.Point(925, 574)
        Me.lblKNSUsername.Name = "lblKNSUsername"
        Me.lblKNSUsername.Size = New System.Drawing.Size(348, 65)
        Me.lblKNSUsername.TabIndex = 2
        Me.lblKNSUsername.Text = "Username:"
        '
        'lblKNSPassword
        '
        Me.lblKNSPassword.AutoSize = True
        Me.lblKNSPassword.BackColor = System.Drawing.Color.Black
        Me.lblKNSPassword.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSPassword.ForeColor = System.Drawing.Color.White
        Me.lblKNSPassword.Location = New System.Drawing.Point(925, 817)
        Me.lblKNSPassword.Name = "lblKNSPassword"
        Me.lblKNSPassword.Size = New System.Drawing.Size(336, 65)
        Me.lblKNSPassword.TabIndex = 3
        Me.lblKNSPassword.Text = "Password:"
        '
        'tbxKNSUsername
        '
        Me.tbxKNSUsername.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxKNSUsername.Location = New System.Drawing.Point(1369, 571)
        Me.tbxKNSUsername.Name = "tbxKNSUsername"
        Me.tbxKNSUsername.Size = New System.Drawing.Size(474, 72)
        Me.tbxKNSUsername.TabIndex = 4
        '
        'txbKNSPassword
        '
        Me.txbKNSPassword.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbKNSPassword.Location = New System.Drawing.Point(1369, 814)
        Me.txbKNSPassword.Name = "txbKNSPassword"
        Me.txbKNSPassword.Size = New System.Drawing.Size(474, 72)
        Me.txbKNSPassword.TabIndex = 5
        '
        'bntKNSSubmit
        '
        Me.bntKNSSubmit.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntKNSSubmit.Location = New System.Drawing.Point(1127, 1094)
        Me.bntKNSSubmit.Name = "bntKNSSubmit"
        Me.bntKNSSubmit.Size = New System.Drawing.Size(500, 144)
        Me.bntKNSSubmit.TabIndex = 6
        Me.bntKNSSubmit.Text = "Submit"
        Me.bntKNSSubmit.UseVisualStyleBackColor = True
        '
        'frmKNSWelcome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2306, 1318)
        Me.Controls.Add(Me.bntKNSSubmit)
        Me.Controls.Add(Me.txbKNSPassword)
        Me.Controls.Add(Me.tbxKNSUsername)
        Me.Controls.Add(Me.lblKNSPassword)
        Me.Controls.Add(Me.lblKNSUsername)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblKNSWelcome)
        Me.DoubleBuffered = True
        Me.Name = "frmKNSWelcome"
        Me.Text = "Welcome Form"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSWelcome As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblKNSUsername As Label
    Friend WithEvents lblKNSPassword As Label
    Friend WithEvents tbxKNSUsername As TextBox
    Friend WithEvents txbKNSPassword As TextBox
    Friend WithEvents bntKNSSubmit As Button
End Class
