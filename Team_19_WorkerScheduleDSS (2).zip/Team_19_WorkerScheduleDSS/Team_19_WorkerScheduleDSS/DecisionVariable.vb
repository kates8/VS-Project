﻿Public Class DecisionVariable
    Public Shared Property DecisionVariableList As New List(Of DecisionVariable)

    Public Property ID As Long
    Public Property Employee As String
    Public Property UM As String
    Public Property Shift1 As Integer
    Public Property Shift2 As Integer
    Public Property Shift3 As Integer
    Public Property Shift4 As Integer
    Public Property Shift5 As Integer
    Public Property Shift6 As Integer



End Class
