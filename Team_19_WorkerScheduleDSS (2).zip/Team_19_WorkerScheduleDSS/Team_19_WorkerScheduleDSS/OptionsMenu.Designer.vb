﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSOptions))
        Me.lblKNSChoiceTitle = New System.Windows.Forms.Label()
        Me.btnKNSAddEmployee = New System.Windows.Forms.Button()
        Me.btnKNSUpdateEmployInfo = New System.Windows.Forms.Button()
        Me.btnKNSCreateSchedule = New System.Windows.Forms.Button()
        Me.btnKNSOptionsLogOut = New System.Windows.Forms.Button()
        Me.btnKNSOptionsInstruc = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblKNSChoiceTitle
        '
        Me.lblKNSChoiceTitle.AutoSize = True
        Me.lblKNSChoiceTitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSChoiceTitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSChoiceTitle.Location = New System.Drawing.Point(517, 58)
        Me.lblKNSChoiceTitle.Name = "lblKNSChoiceTitle"
        Me.lblKNSChoiceTitle.Size = New System.Drawing.Size(1604, 116)
        Me.lblKNSChoiceTitle.TabIndex = 0
        Me.lblKNSChoiceTitle.Text = "What Would You Like To Do?"
        '
        'btnKNSAddEmployee
        '
        Me.btnKNSAddEmployee.BackColor = System.Drawing.Color.Black
        Me.btnKNSAddEmployee.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSAddEmployee.Location = New System.Drawing.Point(955, 278)
        Me.btnKNSAddEmployee.Name = "btnKNSAddEmployee"
        Me.btnKNSAddEmployee.Size = New System.Drawing.Size(672, 188)
        Me.btnKNSAddEmployee.TabIndex = 1
        Me.btnKNSAddEmployee.Text = "Add New Employee"
        Me.btnKNSAddEmployee.UseVisualStyleBackColor = False
        '
        'btnKNSUpdateEmployInfo
        '
        Me.btnKNSUpdateEmployInfo.BackColor = System.Drawing.Color.Black
        Me.btnKNSUpdateEmployInfo.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSUpdateEmployInfo.Location = New System.Drawing.Point(955, 593)
        Me.btnKNSUpdateEmployInfo.Name = "btnKNSUpdateEmployInfo"
        Me.btnKNSUpdateEmployInfo.Size = New System.Drawing.Size(672, 188)
        Me.btnKNSUpdateEmployInfo.TabIndex = 2
        Me.btnKNSUpdateEmployInfo.Text = "Update Employee Information"
        Me.btnKNSUpdateEmployInfo.UseVisualStyleBackColor = False
        '
        'btnKNSCreateSchedule
        '
        Me.btnKNSCreateSchedule.BackColor = System.Drawing.Color.Black
        Me.btnKNSCreateSchedule.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSCreateSchedule.Location = New System.Drawing.Point(955, 899)
        Me.btnKNSCreateSchedule.Name = "btnKNSCreateSchedule"
        Me.btnKNSCreateSchedule.Size = New System.Drawing.Size(672, 188)
        Me.btnKNSCreateSchedule.TabIndex = 3
        Me.btnKNSCreateSchedule.Text = "Create A Schedule"
        Me.btnKNSCreateSchedule.UseVisualStyleBackColor = False
        '
        'btnKNSOptionsLogOut
        '
        Me.btnKNSOptionsLogOut.BackColor = System.Drawing.Color.Black
        Me.btnKNSOptionsLogOut.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSOptionsLogOut.Location = New System.Drawing.Point(1985, 899)
        Me.btnKNSOptionsLogOut.Name = "btnKNSOptionsLogOut"
        Me.btnKNSOptionsLogOut.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSOptionsLogOut.TabIndex = 4
        Me.btnKNSOptionsLogOut.Text = "Log Out"
        Me.btnKNSOptionsLogOut.UseVisualStyleBackColor = False
        '
        'btnKNSOptionsInstruc
        '
        Me.btnKNSOptionsInstruc.BackColor = System.Drawing.Color.Black
        Me.btnKNSOptionsInstruc.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSOptionsInstruc.Location = New System.Drawing.Point(1985, 639)
        Me.btnKNSOptionsInstruc.Name = "btnKNSOptionsInstruc"
        Me.btnKNSOptionsInstruc.Size = New System.Drawing.Size(414, 142)
        Me.btnKNSOptionsInstruc.TabIndex = 5
        Me.btnKNSOptionsInstruc.Text = "View Instructions"
        Me.btnKNSOptionsInstruc.UseVisualStyleBackColor = False
        '
        'frmKNSOptions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2624, 1279)
        Me.Controls.Add(Me.btnKNSOptionsInstruc)
        Me.Controls.Add(Me.btnKNSOptionsLogOut)
        Me.Controls.Add(Me.btnKNSCreateSchedule)
        Me.Controls.Add(Me.btnKNSUpdateEmployInfo)
        Me.Controls.Add(Me.btnKNSAddEmployee)
        Me.Controls.Add(Me.lblKNSChoiceTitle)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "frmKNSOptions"
        Me.Text = "Options"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSChoiceTitle As Label
    Friend WithEvents btnKNSAddEmployee As Button
    Friend WithEvents btnKNSUpdateEmployInfo As Button
    Friend WithEvents btnKNSCreateSchedule As Button
    Friend WithEvents btnKNSOptionsLogOut As Button
    Friend WithEvents btnKNSOptionsInstruc As Button
End Class
