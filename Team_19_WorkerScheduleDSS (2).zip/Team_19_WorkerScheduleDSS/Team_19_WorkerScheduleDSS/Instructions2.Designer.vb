﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Instructions2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Instructions2))
        Me.lblKNSInstruc2UEI = New System.Windows.Forms.Label()
        Me.lblKNSInstructionsTitle = New System.Windows.Forms.Label()
        Me.lblKNSInstruc2CAS = New System.Windows.Forms.Label()
        Me.lblKNSInstruc2CAS2 = New System.Windows.Forms.Label()
        Me.lblKNSInstruc2TWS = New System.Windows.Forms.Label()
        Me.btnKNSInstruc2BackToOptions = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblKNSInstruc2UEI
        '
        Me.lblKNSInstruc2UEI.AutoSize = True
        Me.lblKNSInstruc2UEI.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstruc2UEI.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstruc2UEI.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstruc2UEI.Location = New System.Drawing.Point(74, 210)
        Me.lblKNSInstruc2UEI.Name = "lblKNSInstruc2UEI"
        Me.lblKNSInstruc2UEI.Size = New System.Drawing.Size(1056, 413)
        Me.lblKNSInstruc2UEI.TabIndex = 6
        Me.lblKNSInstruc2UEI.Text = resources.GetString("lblKNSInstruc2UEI.Text")
        '
        'lblKNSInstructionsTitle
        '
        Me.lblKNSInstructionsTitle.AutoSize = True
        Me.lblKNSInstructionsTitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstructionsTitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstructionsTitle.Location = New System.Drawing.Point(987, 22)
        Me.lblKNSInstructionsTitle.Name = "lblKNSInstructionsTitle"
        Me.lblKNSInstructionsTitle.Size = New System.Drawing.Size(711, 116)
        Me.lblKNSInstructionsTitle.TabIndex = 7
        Me.lblKNSInstructionsTitle.Text = "Instructions"
        '
        'lblKNSInstruc2CAS
        '
        Me.lblKNSInstruc2CAS.AutoSize = True
        Me.lblKNSInstruc2CAS.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstruc2CAS.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstruc2CAS.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstruc2CAS.Location = New System.Drawing.Point(74, 658)
        Me.lblKNSInstruc2CAS.Name = "lblKNSInstruc2CAS"
        Me.lblKNSInstruc2CAS.Size = New System.Drawing.Size(1061, 472)
        Me.lblKNSInstruc2CAS.TabIndex = 8
        Me.lblKNSInstruc2CAS.Text = resources.GetString("lblKNSInstruc2CAS.Text")
        '
        'lblKNSInstruc2CAS2
        '
        Me.lblKNSInstruc2CAS2.AutoSize = True
        Me.lblKNSInstruc2CAS2.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstruc2CAS2.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstruc2CAS2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstruc2CAS2.Location = New System.Drawing.Point(1551, 210)
        Me.lblKNSInstruc2CAS2.Name = "lblKNSInstruc2CAS2"
        Me.lblKNSInstruc2CAS2.Size = New System.Drawing.Size(1030, 354)
        Me.lblKNSInstruc2CAS2.TabIndex = 9
        Me.lblKNSInstruc2CAS2.Text = resources.GetString("lblKNSInstruc2CAS2.Text")
        '
        'lblKNSInstruc2TWS
        '
        Me.lblKNSInstruc2TWS.AutoSize = True
        Me.lblKNSInstruc2TWS.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstruc2TWS.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstruc2TWS.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstruc2TWS.Location = New System.Drawing.Point(1551, 658)
        Me.lblKNSInstruc2TWS.Name = "lblKNSInstruc2TWS"
        Me.lblKNSInstruc2TWS.Size = New System.Drawing.Size(949, 354)
        Me.lblKNSInstruc2TWS.TabIndex = 10
        Me.lblKNSInstruc2TWS.Text = "This Week's Schedule Screen: " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "This schedule will show you the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "most optimized sc" &
    "hedule for your" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "week based on your employees." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Clicking Done will bring you to " &
    "the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Options Screen."
        '
        'btnKNSInstruc2BackToOptions
        '
        Me.btnKNSInstruc2BackToOptions.BackColor = System.Drawing.Color.Black
        Me.btnKNSInstruc2BackToOptions.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSInstruc2BackToOptions.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSInstruc2BackToOptions.Location = New System.Drawing.Point(2158, 1061)
        Me.btnKNSInstruc2BackToOptions.Name = "btnKNSInstruc2BackToOptions"
        Me.btnKNSInstruc2BackToOptions.Size = New System.Drawing.Size(423, 144)
        Me.btnKNSInstruc2BackToOptions.TabIndex = 12
        Me.btnKNSInstruc2BackToOptions.Text = "Back To Options"
        Me.btnKNSInstruc2BackToOptions.UseVisualStyleBackColor = False
        '
        'Instructions2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2664, 1237)
        Me.Controls.Add(Me.btnKNSInstruc2BackToOptions)
        Me.Controls.Add(Me.lblKNSInstruc2TWS)
        Me.Controls.Add(Me.lblKNSInstruc2CAS2)
        Me.Controls.Add(Me.lblKNSInstruc2CAS)
        Me.Controls.Add(Me.lblKNSInstructionsTitle)
        Me.Controls.Add(Me.lblKNSInstruc2UEI)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "Instructions2"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSInstruc2UEI As Label
    Friend WithEvents lblKNSInstructionsTitle As Label
    Friend WithEvents lblKNSInstruc2CAS As Label
    Friend WithEvents lblKNSInstruc2CAS2 As Label
    Friend WithEvents lblKNSInstruc2TWS As Label
    Friend WithEvents btnKNSInstruc2BackToOptions As Button
End Class
