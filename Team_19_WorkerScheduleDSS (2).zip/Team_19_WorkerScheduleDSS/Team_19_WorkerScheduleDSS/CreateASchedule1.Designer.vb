﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmKNSCreateASchedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSCreateASchedule))
        Me.lblKNSCASTitle = New System.Windows.Forms.Label()
        Me.btnKNSCASCancel = New System.Windows.Forms.Button()
        Me.btnKNSCASContinue = New System.Windows.Forms.Button()
        Me.lblKNSCASDemandForecast = New System.Windows.Forms.Label()
        Me.txtKNSCASP1 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP2 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP3 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP4 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP5 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP6 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP7 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP8 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP9 = New System.Windows.Forms.TextBox()
        Me.txtKNSCASP10 = New System.Windows.Forms.TextBox()
        Me.lblKNSCASP1 = New System.Windows.Forms.Label()
        Me.lblKNSCASP2 = New System.Windows.Forms.Label()
        Me.lblKNSCASP3 = New System.Windows.Forms.Label()
        Me.lblKNSCASP4 = New System.Windows.Forms.Label()
        Me.lblKNSCASP5 = New System.Windows.Forms.Label()
        Me.lblKNSCASP6 = New System.Windows.Forms.Label()
        Me.lblKNSCASP7 = New System.Windows.Forms.Label()
        Me.lblKNSCASP8 = New System.Windows.Forms.Label()
        Me.lblKNSCASP9 = New System.Windows.Forms.Label()
        Me.lblKNSCASP10 = New System.Windows.Forms.Label()
        Me.lblKNSCASAvgProcessTime = New System.Windows.Forms.Label()
        Me.txtKNSCASAvgProcessTime = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblKNSCASTitle
        '
        Me.lblKNSCASTitle.AutoSize = True
        Me.lblKNSCASTitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASTitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASTitle.Location = New System.Drawing.Point(872, 51)
        Me.lblKNSCASTitle.Name = "lblKNSCASTitle"
        Me.lblKNSCASTitle.Size = New System.Drawing.Size(1032, 116)
        Me.lblKNSCASTitle.TabIndex = 1
        Me.lblKNSCASTitle.Text = "Create A Schedule"
        '
        'btnKNSCASCancel
        '
        Me.btnKNSCASCancel.BackColor = System.Drawing.Color.Black
        Me.btnKNSCASCancel.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSCASCancel.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSCASCancel.Location = New System.Drawing.Point(2240, 901)
        Me.btnKNSCASCancel.Name = "btnKNSCASCancel"
        Me.btnKNSCASCancel.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSCASCancel.TabIndex = 14
        Me.btnKNSCASCancel.Text = "Cancel"
        Me.btnKNSCASCancel.UseVisualStyleBackColor = False
        '
        'btnKNSCASContinue
        '
        Me.btnKNSCASContinue.BackColor = System.Drawing.Color.Black
        Me.btnKNSCASContinue.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSCASContinue.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSCASContinue.Location = New System.Drawing.Point(2240, 1118)
        Me.btnKNSCASContinue.Name = "btnKNSCASContinue"
        Me.btnKNSCASContinue.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSCASContinue.TabIndex = 13
        Me.btnKNSCASContinue.Text = "Continue"
        Me.btnKNSCASContinue.UseVisualStyleBackColor = False
        '
        'lblKNSCASDemandForecast
        '
        Me.lblKNSCASDemandForecast.AutoSize = True
        Me.lblKNSCASDemandForecast.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASDemandForecast.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASDemandForecast.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASDemandForecast.Location = New System.Drawing.Point(25, 362)
        Me.lblKNSCASDemandForecast.Name = "lblKNSCASDemandForecast"
        Me.lblKNSCASDemandForecast.Size = New System.Drawing.Size(564, 65)
        Me.lblKNSCASDemandForecast.TabIndex = 15
        Me.lblKNSCASDemandForecast.Text = "Demand Forecast:"
        '
        'txtKNSCASP1
        '
        Me.txtKNSCASP1.Location = New System.Drawing.Point(613, 359)
        Me.txtKNSCASP1.Name = "txtKNSCASP1"
        Me.txtKNSCASP1.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP1.TabIndex = 16
        '
        'txtKNSCASP2
        '
        Me.txtKNSCASP2.Location = New System.Drawing.Point(805, 359)
        Me.txtKNSCASP2.Name = "txtKNSCASP2"
        Me.txtKNSCASP2.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP2.TabIndex = 17
        '
        'txtKNSCASP3
        '
        Me.txtKNSCASP3.Location = New System.Drawing.Point(995, 359)
        Me.txtKNSCASP3.Name = "txtKNSCASP3"
        Me.txtKNSCASP3.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP3.TabIndex = 18
        '
        'txtKNSCASP4
        '
        Me.txtKNSCASP4.Location = New System.Drawing.Point(1185, 359)
        Me.txtKNSCASP4.Name = "txtKNSCASP4"
        Me.txtKNSCASP4.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP4.TabIndex = 19
        '
        'txtKNSCASP5
        '
        Me.txtKNSCASP5.Location = New System.Drawing.Point(1381, 359)
        Me.txtKNSCASP5.Name = "txtKNSCASP5"
        Me.txtKNSCASP5.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP5.TabIndex = 20
        '
        'txtKNSCASP6
        '
        Me.txtKNSCASP6.Location = New System.Drawing.Point(1579, 359)
        Me.txtKNSCASP6.Name = "txtKNSCASP6"
        Me.txtKNSCASP6.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP6.TabIndex = 21
        '
        'txtKNSCASP7
        '
        Me.txtKNSCASP7.Location = New System.Drawing.Point(1781, 359)
        Me.txtKNSCASP7.Name = "txtKNSCASP7"
        Me.txtKNSCASP7.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP7.TabIndex = 22
        '
        'txtKNSCASP8
        '
        Me.txtKNSCASP8.Location = New System.Drawing.Point(1971, 359)
        Me.txtKNSCASP8.Name = "txtKNSCASP8"
        Me.txtKNSCASP8.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP8.TabIndex = 23
        '
        'txtKNSCASP9
        '
        Me.txtKNSCASP9.Location = New System.Drawing.Point(2163, 359)
        Me.txtKNSCASP9.Name = "txtKNSCASP9"
        Me.txtKNSCASP9.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP9.TabIndex = 24
        '
        'txtKNSCASP10
        '
        Me.txtKNSCASP10.Location = New System.Drawing.Point(2356, 359)
        Me.txtKNSCASP10.Name = "txtKNSCASP10"
        Me.txtKNSCASP10.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASP10.TabIndex = 25
        '
        'lblKNSCASP1
        '
        Me.lblKNSCASP1.AutoSize = True
        Me.lblKNSCASP1.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP1.Location = New System.Drawing.Point(609, 318)
        Me.lblKNSCASP1.Name = "lblKNSCASP1"
        Me.lblKNSCASP1.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP1.TabIndex = 26
        Me.lblKNSCASP1.Text = "Period 1"
        '
        'lblKNSCASP2
        '
        Me.lblKNSCASP2.AutoSize = True
        Me.lblKNSCASP2.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP2.Location = New System.Drawing.Point(801, 318)
        Me.lblKNSCASP2.Name = "lblKNSCASP2"
        Me.lblKNSCASP2.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP2.TabIndex = 27
        Me.lblKNSCASP2.Text = "Period 2"
        '
        'lblKNSCASP3
        '
        Me.lblKNSCASP3.AutoSize = True
        Me.lblKNSCASP3.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP3.Location = New System.Drawing.Point(991, 318)
        Me.lblKNSCASP3.Name = "lblKNSCASP3"
        Me.lblKNSCASP3.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP3.TabIndex = 28
        Me.lblKNSCASP3.Text = "Period 3"
        '
        'lblKNSCASP4
        '
        Me.lblKNSCASP4.AutoSize = True
        Me.lblKNSCASP4.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP4.Location = New System.Drawing.Point(1181, 318)
        Me.lblKNSCASP4.Name = "lblKNSCASP4"
        Me.lblKNSCASP4.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP4.TabIndex = 29
        Me.lblKNSCASP4.Text = "Period 4"
        '
        'lblKNSCASP5
        '
        Me.lblKNSCASP5.AutoSize = True
        Me.lblKNSCASP5.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP5.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP5.Location = New System.Drawing.Point(1377, 318)
        Me.lblKNSCASP5.Name = "lblKNSCASP5"
        Me.lblKNSCASP5.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP5.TabIndex = 30
        Me.lblKNSCASP5.Text = "Period 5"
        '
        'lblKNSCASP6
        '
        Me.lblKNSCASP6.AutoSize = True
        Me.lblKNSCASP6.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP6.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP6.Location = New System.Drawing.Point(1575, 318)
        Me.lblKNSCASP6.Name = "lblKNSCASP6"
        Me.lblKNSCASP6.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP6.TabIndex = 31
        Me.lblKNSCASP6.Text = "Period 6"
        '
        'lblKNSCASP7
        '
        Me.lblKNSCASP7.AutoSize = True
        Me.lblKNSCASP7.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP7.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP7.Location = New System.Drawing.Point(1777, 318)
        Me.lblKNSCASP7.Name = "lblKNSCASP7"
        Me.lblKNSCASP7.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP7.TabIndex = 32
        Me.lblKNSCASP7.Text = "Period 7"
        '
        'lblKNSCASP8
        '
        Me.lblKNSCASP8.AutoSize = True
        Me.lblKNSCASP8.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP8.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP8.Location = New System.Drawing.Point(1967, 318)
        Me.lblKNSCASP8.Name = "lblKNSCASP8"
        Me.lblKNSCASP8.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP8.TabIndex = 33
        Me.lblKNSCASP8.Text = "Period 8"
        '
        'lblKNSCASP9
        '
        Me.lblKNSCASP9.AutoSize = True
        Me.lblKNSCASP9.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP9.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP9.Location = New System.Drawing.Point(2156, 318)
        Me.lblKNSCASP9.Name = "lblKNSCASP9"
        Me.lblKNSCASP9.Size = New System.Drawing.Size(166, 38)
        Me.lblKNSCASP9.TabIndex = 34
        Me.lblKNSCASP9.Text = "Period 9"
        '
        'lblKNSCASP10
        '
        Me.lblKNSCASP10.AutoSize = True
        Me.lblKNSCASP10.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASP10.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASP10.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASP10.Location = New System.Drawing.Point(2352, 318)
        Me.lblKNSCASP10.Name = "lblKNSCASP10"
        Me.lblKNSCASP10.Size = New System.Drawing.Size(189, 38)
        Me.lblKNSCASP10.TabIndex = 35
        Me.lblKNSCASP10.Text = "Period 10"
        '
        'lblKNSCASAvgProcessTime
        '
        Me.lblKNSCASAvgProcessTime.AutoSize = True
        Me.lblKNSCASAvgProcessTime.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASAvgProcessTime.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASAvgProcessTime.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASAvgProcessTime.Location = New System.Drawing.Point(25, 665)
        Me.lblKNSCASAvgProcessTime.Name = "lblKNSCASAvgProcessTime"
        Me.lblKNSCASAvgProcessTime.Size = New System.Drawing.Size(702, 65)
        Me.lblKNSCASAvgProcessTime.TabIndex = 36
        Me.lblKNSCASAvgProcessTime.Text = "Average Process Time:"
        '
        'txtKNSCASAvgProcessTime
        '
        Me.txtKNSCASAvgProcessTime.Location = New System.Drawing.Point(805, 662)
        Me.txtKNSCASAvgProcessTime.Name = "txtKNSCASAvgProcessTime"
        Me.txtKNSCASAvgProcessTime.Size = New System.Drawing.Size(162, 72)
        Me.txtKNSCASAvgProcessTime.TabIndex = 37
        '
        'frmKNSCreateASchedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2704, 1287)
        Me.Controls.Add(Me.txtKNSCASAvgProcessTime)
        Me.Controls.Add(Me.lblKNSCASAvgProcessTime)
        Me.Controls.Add(Me.lblKNSCASP10)
        Me.Controls.Add(Me.lblKNSCASP9)
        Me.Controls.Add(Me.lblKNSCASP8)
        Me.Controls.Add(Me.lblKNSCASP7)
        Me.Controls.Add(Me.lblKNSCASP6)
        Me.Controls.Add(Me.lblKNSCASP5)
        Me.Controls.Add(Me.lblKNSCASP4)
        Me.Controls.Add(Me.lblKNSCASP3)
        Me.Controls.Add(Me.lblKNSCASP2)
        Me.Controls.Add(Me.lblKNSCASP1)
        Me.Controls.Add(Me.txtKNSCASP10)
        Me.Controls.Add(Me.txtKNSCASP9)
        Me.Controls.Add(Me.txtKNSCASP8)
        Me.Controls.Add(Me.txtKNSCASP7)
        Me.Controls.Add(Me.txtKNSCASP6)
        Me.Controls.Add(Me.txtKNSCASP5)
        Me.Controls.Add(Me.txtKNSCASP4)
        Me.Controls.Add(Me.txtKNSCASP3)
        Me.Controls.Add(Me.txtKNSCASP2)
        Me.Controls.Add(Me.txtKNSCASP1)
        Me.Controls.Add(Me.lblKNSCASDemandForecast)
        Me.Controls.Add(Me.btnKNSCASCancel)
        Me.Controls.Add(Me.btnKNSCASContinue)
        Me.Controls.Add(Me.lblKNSCASTitle)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "frmKNSCreateASchedule"
        Me.Text = "Schedule Creator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSCASTitle As Label
    Friend WithEvents btnKNSCASCancel As Button
    Friend WithEvents btnKNSCASContinue As Button
    Friend WithEvents lblKNSCASDemandForecast As Label
    Friend WithEvents txtKNSCASP1 As TextBox
    Friend WithEvents txtKNSCASP2 As TextBox
    Friend WithEvents txtKNSCASP3 As TextBox
    Friend WithEvents txtKNSCASP4 As TextBox
    Friend WithEvents txtKNSCASP5 As TextBox
    Friend WithEvents txtKNSCASP6 As TextBox
    Friend WithEvents txtKNSCASP7 As TextBox
    Friend WithEvents txtKNSCASP8 As TextBox
    Friend WithEvents txtKNSCASP9 As TextBox
    Friend WithEvents txtKNSCASP10 As TextBox
    Friend WithEvents lblKNSCASP1 As Label
    Friend WithEvents lblKNSCASP2 As Label
    Friend WithEvents lblKNSCASP3 As Label
    Friend WithEvents lblKNSCASP4 As Label
    Friend WithEvents lblKNSCASP5 As Label
    Friend WithEvents lblKNSCASP6 As Label
    Friend WithEvents lblKNSCASP7 As Label
    Friend WithEvents lblKNSCASP8 As Label
    Friend WithEvents lblKNSCASP9 As Label
    Friend WithEvents lblKNSCASP10 As Label
    Friend WithEvents lblKNSCASAvgProcessTime As Label
    Friend WithEvents txtKNSCASAvgProcessTime As TextBox
End Class
