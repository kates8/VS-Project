﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSCreateASchedule2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSCreateASchedule2))
        Me.lblKNSCAS2S5 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2S4 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2S3 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2S2 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2S1 = New System.Windows.Forms.Label()
        Me.lblKNSCASShiftPeriodOverlap = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P10 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P9 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P8 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P7 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P6 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P5 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P4 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P3 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P2 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2P1 = New System.Windows.Forms.Label()
        Me.tlpKNSCAS2ShiftPeriodOverlap = New System.Windows.Forms.TableLayoutPanel()
        Me.tbxKNSCAS2P7S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S6 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P2S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P3S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P4S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P5S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P1S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P6S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P7S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P7S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P7S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P7S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P7S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P8S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P9S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S5 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2P10S1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS1 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS2 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS3 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS4 = New System.Windows.Forms.TextBox()
        Me.tbxKNSCAS2THS5 = New System.Windows.Forms.TextBox()
        Me.lblKNSCAS2Title = New System.Windows.Forms.Label()
        Me.lblKNSCAS2S6 = New System.Windows.Forms.Label()
        Me.lblKNSCAS2TotalHours = New System.Windows.Forms.Label()
        Me.btnKNSCAS2Cancel = New System.Windows.Forms.Button()
        Me.btnKNSCAS2Accept = New System.Windows.Forms.Button()
        Me.tlpKNSCAS2ShiftPeriodOverlap.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblKNSCAS2S5
        '
        Me.lblKNSCAS2S5.AutoSize = True
        Me.lblKNSCAS2S5.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S5.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S5.Location = New System.Drawing.Point(189, 858)
        Me.lblKNSCAS2S5.Name = "lblKNSCAS2S5"
        Me.lblKNSCAS2S5.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S5.TabIndex = 72
        Me.lblKNSCAS2S5.Text = "Shift 5"
        '
        'lblKNSCAS2S4
        '
        Me.lblKNSCAS2S4.AutoSize = True
        Me.lblKNSCAS2S4.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S4.Location = New System.Drawing.Point(189, 769)
        Me.lblKNSCAS2S4.Name = "lblKNSCAS2S4"
        Me.lblKNSCAS2S4.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S4.TabIndex = 71
        Me.lblKNSCAS2S4.Text = "Shift 4"
        '
        'lblKNSCAS2S3
        '
        Me.lblKNSCAS2S3.AutoSize = True
        Me.lblKNSCAS2S3.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S3.Location = New System.Drawing.Point(189, 680)
        Me.lblKNSCAS2S3.Name = "lblKNSCAS2S3"
        Me.lblKNSCAS2S3.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S3.TabIndex = 70
        Me.lblKNSCAS2S3.Text = "Shift 3"
        '
        'lblKNSCAS2S2
        '
        Me.lblKNSCAS2S2.AutoSize = True
        Me.lblKNSCAS2S2.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S2.Location = New System.Drawing.Point(189, 591)
        Me.lblKNSCAS2S2.Name = "lblKNSCAS2S2"
        Me.lblKNSCAS2S2.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S2.TabIndex = 69
        Me.lblKNSCAS2S2.Text = "Shift 2"
        '
        'lblKNSCAS2S1
        '
        Me.lblKNSCAS2S1.AutoSize = True
        Me.lblKNSCAS2S1.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S1.Location = New System.Drawing.Point(189, 502)
        Me.lblKNSCAS2S1.Name = "lblKNSCAS2S1"
        Me.lblKNSCAS2S1.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S1.TabIndex = 68
        Me.lblKNSCAS2S1.Text = "Shift 1"
        '
        'lblKNSCASShiftPeriodOverlap
        '
        Me.lblKNSCASShiftPeriodOverlap.AutoSize = True
        Me.lblKNSCASShiftPeriodOverlap.BackColor = System.Drawing.Color.Black
        Me.lblKNSCASShiftPeriodOverlap.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCASShiftPeriodOverlap.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCASShiftPeriodOverlap.Location = New System.Drawing.Point(1069, 273)
        Me.lblKNSCASShiftPeriodOverlap.Name = "lblKNSCASShiftPeriodOverlap"
        Me.lblKNSCASShiftPeriodOverlap.Size = New System.Drawing.Size(632, 65)
        Me.lblKNSCASShiftPeriodOverlap.TabIndex = 67
        Me.lblKNSCASShiftPeriodOverlap.Text = "Shift-Period Overlap"
        '
        'lblKNSCAS2P10
        '
        Me.lblKNSCAS2P10.AutoSize = True
        Me.lblKNSCAS2P10.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P10.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P10.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P10.Location = New System.Drawing.Point(1883, 433)
        Me.lblKNSCAS2P10.Name = "lblKNSCAS2P10"
        Me.lblKNSCAS2P10.Size = New System.Drawing.Size(134, 38)
        Me.lblKNSCAS2P10.TabIndex = 66
        Me.lblKNSCAS2P10.Text = "Per 10"
        '
        'lblKNSCAS2P9
        '
        Me.lblKNSCAS2P9.AutoSize = True
        Me.lblKNSCAS2P9.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P9.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P9.Location = New System.Drawing.Point(1729, 433)
        Me.lblKNSCAS2P9.Name = "lblKNSCAS2P9"
        Me.lblKNSCAS2P9.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P9.TabIndex = 65
        Me.lblKNSCAS2P9.Text = "Per 9"
        '
        'lblKNSCAS2P8
        '
        Me.lblKNSCAS2P8.AutoSize = True
        Me.lblKNSCAS2P8.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P8.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P8.Location = New System.Drawing.Point(1551, 433)
        Me.lblKNSCAS2P8.Name = "lblKNSCAS2P8"
        Me.lblKNSCAS2P8.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P8.TabIndex = 64
        Me.lblKNSCAS2P8.Text = "Per 8"
        '
        'lblKNSCAS2P7
        '
        Me.lblKNSCAS2P7.AutoSize = True
        Me.lblKNSCAS2P7.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P7.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P7.Location = New System.Drawing.Point(1384, 433)
        Me.lblKNSCAS2P7.Name = "lblKNSCAS2P7"
        Me.lblKNSCAS2P7.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P7.TabIndex = 63
        Me.lblKNSCAS2P7.Text = "Per 7"
        '
        'lblKNSCAS2P6
        '
        Me.lblKNSCAS2P6.AutoSize = True
        Me.lblKNSCAS2P6.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P6.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P6.Location = New System.Drawing.Point(1223, 433)
        Me.lblKNSCAS2P6.Name = "lblKNSCAS2P6"
        Me.lblKNSCAS2P6.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P6.TabIndex = 62
        Me.lblKNSCAS2P6.Text = "Per 6"
        '
        'lblKNSCAS2P5
        '
        Me.lblKNSCAS2P5.AutoSize = True
        Me.lblKNSCAS2P5.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P5.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P5.Location = New System.Drawing.Point(1052, 433)
        Me.lblKNSCAS2P5.Name = "lblKNSCAS2P5"
        Me.lblKNSCAS2P5.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P5.TabIndex = 61
        Me.lblKNSCAS2P5.Text = "Per 5"
        '
        'lblKNSCAS2P4
        '
        Me.lblKNSCAS2P4.AutoSize = True
        Me.lblKNSCAS2P4.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P4.Location = New System.Drawing.Point(885, 433)
        Me.lblKNSCAS2P4.Name = "lblKNSCAS2P4"
        Me.lblKNSCAS2P4.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P4.TabIndex = 60
        Me.lblKNSCAS2P4.Text = "Per 4"
        '
        'lblKNSCAS2P3
        '
        Me.lblKNSCAS2P3.AutoSize = True
        Me.lblKNSCAS2P3.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P3.Location = New System.Drawing.Point(720, 433)
        Me.lblKNSCAS2P3.Name = "lblKNSCAS2P3"
        Me.lblKNSCAS2P3.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P3.TabIndex = 59
        Me.lblKNSCAS2P3.Text = "Per 3"
        '
        'lblKNSCAS2P2
        '
        Me.lblKNSCAS2P2.AutoSize = True
        Me.lblKNSCAS2P2.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P2.Location = New System.Drawing.Point(543, 433)
        Me.lblKNSCAS2P2.Name = "lblKNSCAS2P2"
        Me.lblKNSCAS2P2.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P2.TabIndex = 58
        Me.lblKNSCAS2P2.Text = "Per 2"
        '
        'lblKNSCAS2P1
        '
        Me.lblKNSCAS2P1.AutoSize = True
        Me.lblKNSCAS2P1.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2P1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2P1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2P1.Location = New System.Drawing.Point(370, 433)
        Me.lblKNSCAS2P1.Name = "lblKNSCAS2P1"
        Me.lblKNSCAS2P1.Size = New System.Drawing.Size(111, 38)
        Me.lblKNSCAS2P1.TabIndex = 57
        Me.lblKNSCAS2P1.Text = "Per 1"
        '
        'tlpKNSCAS2ShiftPeriodOverlap
        '
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnCount = 11
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS6, 4, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S6, 3, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S6, 2, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S6, 1, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S6, 0, 5)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S5, 4, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S5, 3, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S5, 2, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S5, 1, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S5, 0, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S4, 4, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S4, 3, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S4, 2, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S4, 1, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S4, 0, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S3, 4, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S3, 3, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S3, 2, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S3, 1, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S3, 0, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S2, 4, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S2, 3, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S2, 2, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S2, 0, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S2, 1, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P2S1, 1, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P3S1, 2, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P4S1, 3, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P5S1, 4, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P1S1, 0, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S1, 5, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S2, 5, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S3, 5, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S4, 5, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P6S5, 5, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S1, 6, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S2, 6, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S3, 6, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S4, 6, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P7S5, 6, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S1, 7, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S2, 7, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S3, 7, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S4, 7, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P8S5, 7, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S1, 8, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S2, 8, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S3, 8, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S4, 8, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P9S5, 8, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S5, 9, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S4, 9, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S3, 9, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S2, 9, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2P10S1, 9, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS1, 10, 0)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS2, 10, 1)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS3, 10, 2)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS4, 10, 3)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Controls.Add(Me.tbxKNSCAS2THS5, 10, 4)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tlpKNSCAS2ShiftPeriodOverlap.Location = New System.Drawing.Point(365, 474)
        Me.tlpKNSCAS2ShiftPeriodOverlap.Name = "tlpKNSCAS2ShiftPeriodOverlap"
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowCount = 6
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667!))
        Me.tlpKNSCAS2ShiftPeriodOverlap.Size = New System.Drawing.Size(1859, 538)
        Me.tlpKNSCAS2ShiftPeriodOverlap.TabIndex = 56
        '
        'tbxKNSCAS2P7S6
        '
        Me.tbxKNSCAS2P7S6.Location = New System.Drawing.Point(1011, 448)
        Me.tbxKNSCAS2P7S6.Name = "tbxKNSCAS2P7S6"
        Me.tbxKNSCAS2P7S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S6.TabIndex = 93
        '
        'tbxKNSCAS2P4S6
        '
        Me.tbxKNSCAS2P4S6.Location = New System.Drawing.Point(507, 448)
        Me.tbxKNSCAS2P4S6.Name = "tbxKNSCAS2P4S6"
        Me.tbxKNSCAS2P4S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S6.TabIndex = 92
        '
        'tbxKNSCAS2P5S6
        '
        Me.tbxKNSCAS2P5S6.Location = New System.Drawing.Point(675, 448)
        Me.tbxKNSCAS2P5S6.Name = "tbxKNSCAS2P5S6"
        Me.tbxKNSCAS2P5S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S6.TabIndex = 91
        '
        'tbxKNSCAS2P3S6
        '
        Me.tbxKNSCAS2P3S6.Location = New System.Drawing.Point(339, 448)
        Me.tbxKNSCAS2P3S6.Name = "tbxKNSCAS2P3S6"
        Me.tbxKNSCAS2P3S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S6.TabIndex = 90
        '
        'tbxKNSCAS2P1S6
        '
        Me.tbxKNSCAS2P1S6.Location = New System.Drawing.Point(3, 448)
        Me.tbxKNSCAS2P1S6.Name = "tbxKNSCAS2P1S6"
        Me.tbxKNSCAS2P1S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S6.TabIndex = 89
        '
        'tbxKNSCAS2P2S6
        '
        Me.tbxKNSCAS2P2S6.Location = New System.Drawing.Point(171, 448)
        Me.tbxKNSCAS2P2S6.Name = "tbxKNSCAS2P2S6"
        Me.tbxKNSCAS2P2S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S6.TabIndex = 88
        '
        'tbxKNSCAS2THS6
        '
        Me.tbxKNSCAS2THS6.Location = New System.Drawing.Point(1683, 448)
        Me.tbxKNSCAS2THS6.Name = "tbxKNSCAS2THS6"
        Me.tbxKNSCAS2THS6.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS6.TabIndex = 82
        '
        'tbxKNSCAS2P10S6
        '
        Me.tbxKNSCAS2P10S6.Location = New System.Drawing.Point(1515, 448)
        Me.tbxKNSCAS2P10S6.Name = "tbxKNSCAS2P10S6"
        Me.tbxKNSCAS2P10S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S6.TabIndex = 81
        '
        'tbxKNSCAS2P9S6
        '
        Me.tbxKNSCAS2P9S6.Location = New System.Drawing.Point(1347, 448)
        Me.tbxKNSCAS2P9S6.Name = "tbxKNSCAS2P9S6"
        Me.tbxKNSCAS2P9S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S6.TabIndex = 80
        '
        'tbxKNSCAS2P8S6
        '
        Me.tbxKNSCAS2P8S6.Location = New System.Drawing.Point(1179, 448)
        Me.tbxKNSCAS2P8S6.Name = "tbxKNSCAS2P8S6"
        Me.tbxKNSCAS2P8S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S6.TabIndex = 79
        '
        'tbxKNSCAS2P6S6
        '
        Me.tbxKNSCAS2P6S6.Location = New System.Drawing.Point(843, 448)
        Me.tbxKNSCAS2P6S6.Name = "tbxKNSCAS2P6S6"
        Me.tbxKNSCAS2P6S6.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S6.TabIndex = 78
        '
        'tbxKNSCAS2P5S5
        '
        Me.tbxKNSCAS2P5S5.Location = New System.Drawing.Point(675, 359)
        Me.tbxKNSCAS2P5S5.Name = "tbxKNSCAS2P5S5"
        Me.tbxKNSCAS2P5S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S5.TabIndex = 72
        '
        'tbxKNSCAS2P4S5
        '
        Me.tbxKNSCAS2P4S5.Location = New System.Drawing.Point(507, 359)
        Me.tbxKNSCAS2P4S5.Name = "tbxKNSCAS2P4S5"
        Me.tbxKNSCAS2P4S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S5.TabIndex = 71
        '
        'tbxKNSCAS2P3S5
        '
        Me.tbxKNSCAS2P3S5.Location = New System.Drawing.Point(339, 359)
        Me.tbxKNSCAS2P3S5.Name = "tbxKNSCAS2P3S5"
        Me.tbxKNSCAS2P3S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S5.TabIndex = 70
        '
        'tbxKNSCAS2P2S5
        '
        Me.tbxKNSCAS2P2S5.Location = New System.Drawing.Point(171, 359)
        Me.tbxKNSCAS2P2S5.Name = "tbxKNSCAS2P2S5"
        Me.tbxKNSCAS2P2S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S5.TabIndex = 69
        '
        'tbxKNSCAS2P1S5
        '
        Me.tbxKNSCAS2P1S5.Location = New System.Drawing.Point(3, 359)
        Me.tbxKNSCAS2P1S5.Name = "tbxKNSCAS2P1S5"
        Me.tbxKNSCAS2P1S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S5.TabIndex = 68
        '
        'tbxKNSCAS2P5S4
        '
        Me.tbxKNSCAS2P5S4.Location = New System.Drawing.Point(675, 270)
        Me.tbxKNSCAS2P5S4.Name = "tbxKNSCAS2P5S4"
        Me.tbxKNSCAS2P5S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S4.TabIndex = 62
        '
        'tbxKNSCAS2P4S4
        '
        Me.tbxKNSCAS2P4S4.Location = New System.Drawing.Point(507, 270)
        Me.tbxKNSCAS2P4S4.Name = "tbxKNSCAS2P4S4"
        Me.tbxKNSCAS2P4S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S4.TabIndex = 61
        '
        'tbxKNSCAS2P3S4
        '
        Me.tbxKNSCAS2P3S4.Location = New System.Drawing.Point(339, 270)
        Me.tbxKNSCAS2P3S4.Name = "tbxKNSCAS2P3S4"
        Me.tbxKNSCAS2P3S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S4.TabIndex = 60
        '
        'tbxKNSCAS2P2S4
        '
        Me.tbxKNSCAS2P2S4.Location = New System.Drawing.Point(171, 270)
        Me.tbxKNSCAS2P2S4.Name = "tbxKNSCAS2P2S4"
        Me.tbxKNSCAS2P2S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S4.TabIndex = 59
        '
        'tbxKNSCAS2P1S4
        '
        Me.tbxKNSCAS2P1S4.Location = New System.Drawing.Point(3, 270)
        Me.tbxKNSCAS2P1S4.Name = "tbxKNSCAS2P1S4"
        Me.tbxKNSCAS2P1S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S4.TabIndex = 58
        '
        'tbxKNSCAS2P5S3
        '
        Me.tbxKNSCAS2P5S3.Location = New System.Drawing.Point(675, 181)
        Me.tbxKNSCAS2P5S3.Name = "tbxKNSCAS2P5S3"
        Me.tbxKNSCAS2P5S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S3.TabIndex = 52
        '
        'tbxKNSCAS2P4S3
        '
        Me.tbxKNSCAS2P4S3.Location = New System.Drawing.Point(507, 181)
        Me.tbxKNSCAS2P4S3.Name = "tbxKNSCAS2P4S3"
        Me.tbxKNSCAS2P4S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S3.TabIndex = 51
        '
        'tbxKNSCAS2P3S3
        '
        Me.tbxKNSCAS2P3S3.Location = New System.Drawing.Point(339, 181)
        Me.tbxKNSCAS2P3S3.Name = "tbxKNSCAS2P3S3"
        Me.tbxKNSCAS2P3S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S3.TabIndex = 50
        '
        'tbxKNSCAS2P2S3
        '
        Me.tbxKNSCAS2P2S3.Location = New System.Drawing.Point(171, 181)
        Me.tbxKNSCAS2P2S3.Name = "tbxKNSCAS2P2S3"
        Me.tbxKNSCAS2P2S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S3.TabIndex = 49
        '
        'tbxKNSCAS2P1S3
        '
        Me.tbxKNSCAS2P1S3.Location = New System.Drawing.Point(3, 181)
        Me.tbxKNSCAS2P1S3.Name = "tbxKNSCAS2P1S3"
        Me.tbxKNSCAS2P1S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S3.TabIndex = 48
        '
        'tbxKNSCAS2P5S2
        '
        Me.tbxKNSCAS2P5S2.Location = New System.Drawing.Point(675, 92)
        Me.tbxKNSCAS2P5S2.Name = "tbxKNSCAS2P5S2"
        Me.tbxKNSCAS2P5S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S2.TabIndex = 42
        '
        'tbxKNSCAS2P4S2
        '
        Me.tbxKNSCAS2P4S2.Location = New System.Drawing.Point(507, 92)
        Me.tbxKNSCAS2P4S2.Name = "tbxKNSCAS2P4S2"
        Me.tbxKNSCAS2P4S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S2.TabIndex = 41
        '
        'tbxKNSCAS2P3S2
        '
        Me.tbxKNSCAS2P3S2.Location = New System.Drawing.Point(339, 92)
        Me.tbxKNSCAS2P3S2.Name = "tbxKNSCAS2P3S2"
        Me.tbxKNSCAS2P3S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S2.TabIndex = 40
        '
        'tbxKNSCAS2P1S2
        '
        Me.tbxKNSCAS2P1S2.Location = New System.Drawing.Point(3, 92)
        Me.tbxKNSCAS2P1S2.Name = "tbxKNSCAS2P1S2"
        Me.tbxKNSCAS2P1S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S2.TabIndex = 39
        '
        'tbxKNSCAS2P2S2
        '
        Me.tbxKNSCAS2P2S2.Location = New System.Drawing.Point(171, 92)
        Me.tbxKNSCAS2P2S2.Name = "tbxKNSCAS2P2S2"
        Me.tbxKNSCAS2P2S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S2.TabIndex = 17
        '
        'tbxKNSCAS2P2S1
        '
        Me.tbxKNSCAS2P2S1.Location = New System.Drawing.Point(171, 3)
        Me.tbxKNSCAS2P2S1.Name = "tbxKNSCAS2P2S1"
        Me.tbxKNSCAS2P2S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P2S1.TabIndex = 19
        '
        'tbxKNSCAS2P3S1
        '
        Me.tbxKNSCAS2P3S1.Location = New System.Drawing.Point(339, 3)
        Me.tbxKNSCAS2P3S1.Name = "tbxKNSCAS2P3S1"
        Me.tbxKNSCAS2P3S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P3S1.TabIndex = 20
        '
        'tbxKNSCAS2P4S1
        '
        Me.tbxKNSCAS2P4S1.Location = New System.Drawing.Point(507, 3)
        Me.tbxKNSCAS2P4S1.Name = "tbxKNSCAS2P4S1"
        Me.tbxKNSCAS2P4S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P4S1.TabIndex = 22
        '
        'tbxKNSCAS2P5S1
        '
        Me.tbxKNSCAS2P5S1.Location = New System.Drawing.Point(675, 3)
        Me.tbxKNSCAS2P5S1.Name = "tbxKNSCAS2P5S1"
        Me.tbxKNSCAS2P5S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P5S1.TabIndex = 23
        '
        'tbxKNSCAS2P1S1
        '
        Me.tbxKNSCAS2P1S1.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxKNSCAS2P1S1.Location = New System.Drawing.Point(3, 3)
        Me.tbxKNSCAS2P1S1.Name = "tbxKNSCAS2P1S1"
        Me.tbxKNSCAS2P1S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P1S1.TabIndex = 21
        '
        'tbxKNSCAS2P6S1
        '
        Me.tbxKNSCAS2P6S1.Location = New System.Drawing.Point(843, 3)
        Me.tbxKNSCAS2P6S1.Name = "tbxKNSCAS2P6S1"
        Me.tbxKNSCAS2P6S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S1.TabIndex = 24
        '
        'tbxKNSCAS2P6S2
        '
        Me.tbxKNSCAS2P6S2.Location = New System.Drawing.Point(843, 92)
        Me.tbxKNSCAS2P6S2.Name = "tbxKNSCAS2P6S2"
        Me.tbxKNSCAS2P6S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S2.TabIndex = 43
        '
        'tbxKNSCAS2P6S3
        '
        Me.tbxKNSCAS2P6S3.Location = New System.Drawing.Point(843, 181)
        Me.tbxKNSCAS2P6S3.Name = "tbxKNSCAS2P6S3"
        Me.tbxKNSCAS2P6S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S3.TabIndex = 53
        '
        'tbxKNSCAS2P6S4
        '
        Me.tbxKNSCAS2P6S4.Location = New System.Drawing.Point(843, 270)
        Me.tbxKNSCAS2P6S4.Name = "tbxKNSCAS2P6S4"
        Me.tbxKNSCAS2P6S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S4.TabIndex = 63
        '
        'tbxKNSCAS2P6S5
        '
        Me.tbxKNSCAS2P6S5.Location = New System.Drawing.Point(843, 359)
        Me.tbxKNSCAS2P6S5.Name = "tbxKNSCAS2P6S5"
        Me.tbxKNSCAS2P6S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P6S5.TabIndex = 73
        '
        'tbxKNSCAS2P7S1
        '
        Me.tbxKNSCAS2P7S1.Location = New System.Drawing.Point(1011, 3)
        Me.tbxKNSCAS2P7S1.Name = "tbxKNSCAS2P7S1"
        Me.tbxKNSCAS2P7S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S1.TabIndex = 25
        '
        'tbxKNSCAS2P7S2
        '
        Me.tbxKNSCAS2P7S2.Location = New System.Drawing.Point(1011, 92)
        Me.tbxKNSCAS2P7S2.Name = "tbxKNSCAS2P7S2"
        Me.tbxKNSCAS2P7S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S2.TabIndex = 44
        '
        'tbxKNSCAS2P7S3
        '
        Me.tbxKNSCAS2P7S3.Location = New System.Drawing.Point(1011, 181)
        Me.tbxKNSCAS2P7S3.Name = "tbxKNSCAS2P7S3"
        Me.tbxKNSCAS2P7S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S3.TabIndex = 54
        '
        'tbxKNSCAS2P7S4
        '
        Me.tbxKNSCAS2P7S4.Location = New System.Drawing.Point(1011, 270)
        Me.tbxKNSCAS2P7S4.Name = "tbxKNSCAS2P7S4"
        Me.tbxKNSCAS2P7S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S4.TabIndex = 64
        '
        'tbxKNSCAS2P7S5
        '
        Me.tbxKNSCAS2P7S5.Location = New System.Drawing.Point(1011, 359)
        Me.tbxKNSCAS2P7S5.Name = "tbxKNSCAS2P7S5"
        Me.tbxKNSCAS2P7S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P7S5.TabIndex = 74
        '
        'tbxKNSCAS2P8S1
        '
        Me.tbxKNSCAS2P8S1.Location = New System.Drawing.Point(1179, 3)
        Me.tbxKNSCAS2P8S1.Name = "tbxKNSCAS2P8S1"
        Me.tbxKNSCAS2P8S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S1.TabIndex = 18
        '
        'tbxKNSCAS2P8S2
        '
        Me.tbxKNSCAS2P8S2.Location = New System.Drawing.Point(1179, 92)
        Me.tbxKNSCAS2P8S2.Name = "tbxKNSCAS2P8S2"
        Me.tbxKNSCAS2P8S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S2.TabIndex = 45
        '
        'tbxKNSCAS2P8S3
        '
        Me.tbxKNSCAS2P8S3.Location = New System.Drawing.Point(1179, 181)
        Me.tbxKNSCAS2P8S3.Name = "tbxKNSCAS2P8S3"
        Me.tbxKNSCAS2P8S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S3.TabIndex = 55
        '
        'tbxKNSCAS2P8S4
        '
        Me.tbxKNSCAS2P8S4.Location = New System.Drawing.Point(1179, 270)
        Me.tbxKNSCAS2P8S4.Name = "tbxKNSCAS2P8S4"
        Me.tbxKNSCAS2P8S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S4.TabIndex = 65
        '
        'tbxKNSCAS2P8S5
        '
        Me.tbxKNSCAS2P8S5.Location = New System.Drawing.Point(1179, 359)
        Me.tbxKNSCAS2P8S5.Name = "tbxKNSCAS2P8S5"
        Me.tbxKNSCAS2P8S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P8S5.TabIndex = 75
        '
        'tbxKNSCAS2P9S1
        '
        Me.tbxKNSCAS2P9S1.Location = New System.Drawing.Point(1347, 3)
        Me.tbxKNSCAS2P9S1.Name = "tbxKNSCAS2P9S1"
        Me.tbxKNSCAS2P9S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S1.TabIndex = 26
        '
        'tbxKNSCAS2P9S2
        '
        Me.tbxKNSCAS2P9S2.Location = New System.Drawing.Point(1347, 92)
        Me.tbxKNSCAS2P9S2.Name = "tbxKNSCAS2P9S2"
        Me.tbxKNSCAS2P9S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S2.TabIndex = 46
        '
        'tbxKNSCAS2P9S3
        '
        Me.tbxKNSCAS2P9S3.Location = New System.Drawing.Point(1347, 181)
        Me.tbxKNSCAS2P9S3.Name = "tbxKNSCAS2P9S3"
        Me.tbxKNSCAS2P9S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S3.TabIndex = 56
        '
        'tbxKNSCAS2P9S4
        '
        Me.tbxKNSCAS2P9S4.Location = New System.Drawing.Point(1347, 270)
        Me.tbxKNSCAS2P9S4.Name = "tbxKNSCAS2P9S4"
        Me.tbxKNSCAS2P9S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S4.TabIndex = 66
        '
        'tbxKNSCAS2P9S5
        '
        Me.tbxKNSCAS2P9S5.Location = New System.Drawing.Point(1347, 359)
        Me.tbxKNSCAS2P9S5.Name = "tbxKNSCAS2P9S5"
        Me.tbxKNSCAS2P9S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P9S5.TabIndex = 76
        '
        'tbxKNSCAS2P10S5
        '
        Me.tbxKNSCAS2P10S5.Location = New System.Drawing.Point(1515, 359)
        Me.tbxKNSCAS2P10S5.Name = "tbxKNSCAS2P10S5"
        Me.tbxKNSCAS2P10S5.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S5.TabIndex = 77
        '
        'tbxKNSCAS2P10S4
        '
        Me.tbxKNSCAS2P10S4.Location = New System.Drawing.Point(1515, 270)
        Me.tbxKNSCAS2P10S4.Name = "tbxKNSCAS2P10S4"
        Me.tbxKNSCAS2P10S4.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S4.TabIndex = 67
        '
        'tbxKNSCAS2P10S3
        '
        Me.tbxKNSCAS2P10S3.Location = New System.Drawing.Point(1515, 181)
        Me.tbxKNSCAS2P10S3.Name = "tbxKNSCAS2P10S3"
        Me.tbxKNSCAS2P10S3.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S3.TabIndex = 57
        '
        'tbxKNSCAS2P10S2
        '
        Me.tbxKNSCAS2P10S2.Location = New System.Drawing.Point(1515, 92)
        Me.tbxKNSCAS2P10S2.Name = "tbxKNSCAS2P10S2"
        Me.tbxKNSCAS2P10S2.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S2.TabIndex = 47
        '
        'tbxKNSCAS2P10S1
        '
        Me.tbxKNSCAS2P10S1.Location = New System.Drawing.Point(1515, 3)
        Me.tbxKNSCAS2P10S1.Name = "tbxKNSCAS2P10S1"
        Me.tbxKNSCAS2P10S1.Size = New System.Drawing.Size(162, 72)
        Me.tbxKNSCAS2P10S1.TabIndex = 27
        '
        'tbxKNSCAS2THS1
        '
        Me.tbxKNSCAS2THS1.Location = New System.Drawing.Point(1683, 3)
        Me.tbxKNSCAS2THS1.Name = "tbxKNSCAS2THS1"
        Me.tbxKNSCAS2THS1.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS1.TabIndex = 87
        '
        'tbxKNSCAS2THS2
        '
        Me.tbxKNSCAS2THS2.Location = New System.Drawing.Point(1683, 92)
        Me.tbxKNSCAS2THS2.Name = "tbxKNSCAS2THS2"
        Me.tbxKNSCAS2THS2.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS2.TabIndex = 86
        '
        'tbxKNSCAS2THS3
        '
        Me.tbxKNSCAS2THS3.Location = New System.Drawing.Point(1683, 181)
        Me.tbxKNSCAS2THS3.Name = "tbxKNSCAS2THS3"
        Me.tbxKNSCAS2THS3.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS3.TabIndex = 85
        '
        'tbxKNSCAS2THS4
        '
        Me.tbxKNSCAS2THS4.Location = New System.Drawing.Point(1683, 270)
        Me.tbxKNSCAS2THS4.Name = "tbxKNSCAS2THS4"
        Me.tbxKNSCAS2THS4.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS4.TabIndex = 84
        '
        'tbxKNSCAS2THS5
        '
        Me.tbxKNSCAS2THS5.Location = New System.Drawing.Point(1683, 359)
        Me.tbxKNSCAS2THS5.Name = "tbxKNSCAS2THS5"
        Me.tbxKNSCAS2THS5.Size = New System.Drawing.Size(173, 72)
        Me.tbxKNSCAS2THS5.TabIndex = 83
        '
        'lblKNSCAS2Title
        '
        Me.lblKNSCAS2Title.AutoSize = True
        Me.lblKNSCAS2Title.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2Title.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2Title.Location = New System.Drawing.Point(905, 37)
        Me.lblKNSCAS2Title.Name = "lblKNSCAS2Title"
        Me.lblKNSCAS2Title.Size = New System.Drawing.Size(1032, 116)
        Me.lblKNSCAS2Title.TabIndex = 74
        Me.lblKNSCAS2Title.Text = "Create A Schedule"
        '
        'lblKNSCAS2S6
        '
        Me.lblKNSCAS2S6.AutoSize = True
        Me.lblKNSCAS2S6.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2S6.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2S6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2S6.Location = New System.Drawing.Point(189, 947)
        Me.lblKNSCAS2S6.Name = "lblKNSCAS2S6"
        Me.lblKNSCAS2S6.Size = New System.Drawing.Size(137, 38)
        Me.lblKNSCAS2S6.TabIndex = 75
        Me.lblKNSCAS2S6.Text = "Shift 6"
        '
        'lblKNSCAS2TotalHours
        '
        Me.lblKNSCAS2TotalHours.BackColor = System.Drawing.Color.Black
        Me.lblKNSCAS2TotalHours.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSCAS2TotalHours.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSCAS2TotalHours.Location = New System.Drawing.Point(2063, 391)
        Me.lblKNSCAS2TotalHours.Name = "lblKNSCAS2TotalHours"
        Me.lblKNSCAS2TotalHours.Size = New System.Drawing.Size(134, 80)
        Me.lblKNSCAS2TotalHours.TabIndex = 76
        Me.lblKNSCAS2TotalHours.Text = "Total Hours"
        Me.lblKNSCAS2TotalHours.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnKNSCAS2Cancel
        '
        Me.btnKNSCAS2Cancel.BackColor = System.Drawing.Color.Black
        Me.btnKNSCAS2Cancel.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSCAS2Cancel.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSCAS2Cancel.Location = New System.Drawing.Point(2266, 909)
        Me.btnKNSCAS2Cancel.Name = "btnKNSCAS2Cancel"
        Me.btnKNSCAS2Cancel.Size = New System.Drawing.Size(342, 97)
        Me.btnKNSCAS2Cancel.TabIndex = 78
        Me.btnKNSCAS2Cancel.Text = "Cancel"
        Me.btnKNSCAS2Cancel.UseVisualStyleBackColor = False
        '
        'btnKNSCAS2Accept
        '
        Me.btnKNSCAS2Accept.BackColor = System.Drawing.Color.Black
        Me.btnKNSCAS2Accept.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSCAS2Accept.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSCAS2Accept.Location = New System.Drawing.Point(2266, 1093)
        Me.btnKNSCAS2Accept.Name = "btnKNSCAS2Accept"
        Me.btnKNSCAS2Accept.Size = New System.Drawing.Size(342, 100)
        Me.btnKNSCAS2Accept.TabIndex = 77
        Me.btnKNSCAS2Accept.Text = "Accept"
        Me.btnKNSCAS2Accept.UseVisualStyleBackColor = False
        '
        'frmKNSCreateASchedule2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(15.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2620, 1272)
        Me.Controls.Add(Me.btnKNSCAS2Cancel)
        Me.Controls.Add(Me.btnKNSCAS2Accept)
        Me.Controls.Add(Me.lblKNSCAS2TotalHours)
        Me.Controls.Add(Me.lblKNSCAS2S6)
        Me.Controls.Add(Me.lblKNSCAS2Title)
        Me.Controls.Add(Me.lblKNSCAS2S5)
        Me.Controls.Add(Me.lblKNSCAS2S4)
        Me.Controls.Add(Me.lblKNSCAS2S3)
        Me.Controls.Add(Me.lblKNSCAS2S2)
        Me.Controls.Add(Me.lblKNSCAS2S1)
        Me.Controls.Add(Me.lblKNSCASShiftPeriodOverlap)
        Me.Controls.Add(Me.lblKNSCAS2P10)
        Me.Controls.Add(Me.lblKNSCAS2P9)
        Me.Controls.Add(Me.lblKNSCAS2P8)
        Me.Controls.Add(Me.lblKNSCAS2P7)
        Me.Controls.Add(Me.lblKNSCAS2P6)
        Me.Controls.Add(Me.lblKNSCAS2P5)
        Me.Controls.Add(Me.lblKNSCAS2P4)
        Me.Controls.Add(Me.lblKNSCAS2P3)
        Me.Controls.Add(Me.lblKNSCAS2P2)
        Me.Controls.Add(Me.lblKNSCAS2P1)
        Me.Controls.Add(Me.tlpKNSCAS2ShiftPeriodOverlap)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 7.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmKNSCreateASchedule2"
        Me.Text = "Input Shift-Period Overlap"
        Me.tlpKNSCAS2ShiftPeriodOverlap.ResumeLayout(False)
        Me.tlpKNSCAS2ShiftPeriodOverlap.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblKNSCAS2S5 As Label
    Friend WithEvents lblKNSCAS2S4 As Label
    Friend WithEvents lblKNSCAS2S3 As Label
    Friend WithEvents lblKNSCAS2S2 As Label
    Friend WithEvents lblKNSCAS2S1 As Label
    Friend WithEvents lblKNSCASShiftPeriodOverlap As Label
    Friend WithEvents lblKNSCAS2P10 As Label
    Friend WithEvents lblKNSCAS2P9 As Label
    Friend WithEvents lblKNSCAS2P8 As Label
    Friend WithEvents lblKNSCAS2P7 As Label
    Friend WithEvents lblKNSCAS2P6 As Label
    Friend WithEvents lblKNSCAS2P5 As Label
    Friend WithEvents lblKNSCAS2P4 As Label
    Friend WithEvents lblKNSCAS2P3 As Label
    Friend WithEvents lblKNSCAS2P2 As Label
    Friend WithEvents lblKNSCAS2P1 As Label
    Friend WithEvents tlpKNSCAS2ShiftPeriodOverlap As TableLayoutPanel
    Friend WithEvents tbxKNSCAS2THS1 As TextBox
    Friend WithEvents tbxKNSCAS2THS2 As TextBox
    Friend WithEvents tbxKNSCAS2THS3 As TextBox
    Friend WithEvents tbxKNSCAS2THS4 As TextBox
    Friend WithEvents tbxKNSCAS2THS5 As TextBox
    Friend WithEvents tbxKNSCAS2THS6 As TextBox
    Friend WithEvents tbxKNSCAS2P10S6 As TextBox
    Friend WithEvents tbxKNSCAS2P9S6 As TextBox
    Friend WithEvents tbxKNSCAS2P8S6 As TextBox
    Friend WithEvents tbxKNSCAS2P6S6 As TextBox
    Friend WithEvents tbxKNSCAS2P10S5 As TextBox
    Friend WithEvents tbxKNSCAS2P9S5 As TextBox
    Friend WithEvents tbxKNSCAS2P8S5 As TextBox
    Friend WithEvents tbxKNSCAS2P7S5 As TextBox
    Friend WithEvents tbxKNSCAS2P6S5 As TextBox
    Friend WithEvents tbxKNSCAS2P5S5 As TextBox
    Friend WithEvents tbxKNSCAS2P4S5 As TextBox
    Friend WithEvents tbxKNSCAS2P3S5 As TextBox
    Friend WithEvents tbxKNSCAS2P2S5 As TextBox
    Friend WithEvents tbxKNSCAS2P1S5 As TextBox
    Friend WithEvents tbxKNSCAS2P10S4 As TextBox
    Friend WithEvents tbxKNSCAS2P9S4 As TextBox
    Friend WithEvents tbxKNSCAS2P8S4 As TextBox
    Friend WithEvents tbxKNSCAS2P7S4 As TextBox
    Friend WithEvents tbxKNSCAS2P6S4 As TextBox
    Friend WithEvents tbxKNSCAS2P5S4 As TextBox
    Friend WithEvents tbxKNSCAS2P4S4 As TextBox
    Friend WithEvents tbxKNSCAS2P3S4 As TextBox
    Friend WithEvents tbxKNSCAS2P2S4 As TextBox
    Friend WithEvents tbxKNSCAS2P1S4 As TextBox
    Friend WithEvents tbxKNSCAS2P10S3 As TextBox
    Friend WithEvents tbxKNSCAS2P9S3 As TextBox
    Friend WithEvents tbxKNSCAS2P8S3 As TextBox
    Friend WithEvents tbxKNSCAS2P7S3 As TextBox
    Friend WithEvents tbxKNSCAS2P6S3 As TextBox
    Friend WithEvents tbxKNSCAS2P5S3 As TextBox
    Friend WithEvents tbxKNSCAS2P4S3 As TextBox
    Friend WithEvents tbxKNSCAS2P3S3 As TextBox
    Friend WithEvents tbxKNSCAS2P2S3 As TextBox
    Friend WithEvents tbxKNSCAS2P1S3 As TextBox
    Friend WithEvents tbxKNSCAS2P10S2 As TextBox
    Friend WithEvents tbxKNSCAS2P9S2 As TextBox
    Friend WithEvents tbxKNSCAS2P8S2 As TextBox
    Friend WithEvents tbxKNSCAS2P7S2 As TextBox
    Friend WithEvents tbxKNSCAS2P6S2 As TextBox
    Friend WithEvents tbxKNSCAS2P5S2 As TextBox
    Friend WithEvents tbxKNSCAS2P4S2 As TextBox
    Friend WithEvents tbxKNSCAS2P3S2 As TextBox
    Friend WithEvents tbxKNSCAS2P1S2 As TextBox
    Friend WithEvents tbxKNSCAS2P2S2 As TextBox
    Friend WithEvents tbxKNSCAS2P2S1 As TextBox
    Friend WithEvents tbxKNSCAS2P3S1 As TextBox
    Friend WithEvents tbxKNSCAS2P4S1 As TextBox
    Friend WithEvents tbxKNSCAS2P5S1 As TextBox
    Friend WithEvents tbxKNSCAS2P6S1 As TextBox
    Friend WithEvents tbxKNSCAS2P7S1 As TextBox
    Friend WithEvents tbxKNSCAS2P8S1 As TextBox
    Friend WithEvents tbxKNSCAS2P9S1 As TextBox
    Friend WithEvents tbxKNSCAS2P10S1 As TextBox
    Friend WithEvents tbxKNSCAS2P1S1 As TextBox
    Friend WithEvents lblKNSCAS2Title As Label
    Friend WithEvents lblKNSCAS2S6 As Label
    Friend WithEvents tbxKNSCAS2P7S6 As TextBox
    Friend WithEvents tbxKNSCAS2P4S6 As TextBox
    Friend WithEvents tbxKNSCAS2P5S6 As TextBox
    Friend WithEvents tbxKNSCAS2P3S6 As TextBox
    Friend WithEvents tbxKNSCAS2P1S6 As TextBox
    Friend WithEvents tbxKNSCAS2P2S6 As TextBox
    Friend WithEvents lblKNSCAS2TotalHours As Label
    Friend WithEvents btnKNSCAS2Cancel As Button
    Friend WithEvents btnKNSCAS2Accept As Button
End Class
