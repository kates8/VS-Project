﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmKNSInstructions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSInstructions))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblKNSInstructionsTitle = New System.Windows.Forms.Label()
        Me.lblKNSInstrucWS = New System.Windows.Forms.Label()
        Me.lblKNSInstrucOS = New System.Windows.Forms.Label()
        Me.lblKNSInstrucANEIS = New System.Windows.Forms.Label()
        Me.btnKNSInstrucBack = New System.Windows.Forms.Button()
        Me.btnKNSInstrucContinue = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3080, 135)
        Me.Label1.Margin = New System.Windows.Forms.Padding(9, 0, 9, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(225, 65)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Label1"
        '
        'lblKNSInstructionsTitle
        '
        Me.lblKNSInstructionsTitle.AutoSize = True
        Me.lblKNSInstructionsTitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstructionsTitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstructionsTitle.Location = New System.Drawing.Point(953, 9)
        Me.lblKNSInstructionsTitle.Name = "lblKNSInstructionsTitle"
        Me.lblKNSInstructionsTitle.Size = New System.Drawing.Size(711, 116)
        Me.lblKNSInstructionsTitle.TabIndex = 1
        Me.lblKNSInstructionsTitle.Text = "Instructions"
        '
        'lblKNSInstrucWS
        '
        Me.lblKNSInstrucWS.AutoSize = True
        Me.lblKNSInstrucWS.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstrucWS.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstrucWS.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstrucWS.Location = New System.Drawing.Point(606, 222)
        Me.lblKNSInstrucWS.Name = "lblKNSInstrucWS"
        Me.lblKNSInstrucWS.Size = New System.Drawing.Size(1392, 59)
        Me.lblKNSInstrucWS.TabIndex = 2
        Me.lblKNSInstrucWS.Text = "Welcome Screen: Enter in username and password"
        '
        'lblKNSInstrucOS
        '
        Me.lblKNSInstrucOS.AutoSize = True
        Me.lblKNSInstrucOS.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstrucOS.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstrucOS.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstrucOS.Location = New System.Drawing.Point(648, 364)
        Me.lblKNSInstrucOS.Name = "lblKNSInstrucOS"
        Me.lblKNSInstrucOS.Size = New System.Drawing.Size(1294, 236)
        Me.lblKNSInstrucOS.TabIndex = 3
        Me.lblKNSInstrucOS.Text = "Options Screen: You can add a new employee's" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "information, update existing employ" &
    "ee " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "information, create a schedule for a week, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "or log out(return to welcome s" &
    "creen)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblKNSInstrucANEIS
        '
        Me.lblKNSInstrucANEIS.AutoSize = True
        Me.lblKNSInstrucANEIS.BackColor = System.Drawing.Color.Black
        Me.lblKNSInstrucANEIS.Font = New System.Drawing.Font("Verdana", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSInstrucANEIS.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSInstrucANEIS.Location = New System.Drawing.Point(748, 711)
        Me.lblKNSInstrucANEIS.Name = "lblKNSInstrucANEIS"
        Me.lblKNSInstrucANEIS.Size = New System.Drawing.Size(1125, 354)
        Me.lblKNSInstrucANEIS.TabIndex = 4
        Me.lblKNSInstrucANEIS.Text = resources.GetString("lblKNSInstrucANEIS.Text")
        '
        'btnKNSInstrucBack
        '
        Me.btnKNSInstrucBack.BackColor = System.Drawing.Color.Black
        Me.btnKNSInstrucBack.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSInstrucBack.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSInstrucBack.Location = New System.Drawing.Point(2126, 720)
        Me.btnKNSInstrucBack.Name = "btnKNSInstrucBack"
        Me.btnKNSInstrucBack.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSInstrucBack.TabIndex = 12
        Me.btnKNSInstrucBack.Text = "Back"
        Me.btnKNSInstrucBack.UseVisualStyleBackColor = False
        '
        'btnKNSInstrucContinue
        '
        Me.btnKNSInstrucContinue.BackColor = System.Drawing.Color.Black
        Me.btnKNSInstrucContinue.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSInstrucContinue.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSInstrucContinue.Location = New System.Drawing.Point(2126, 937)
        Me.btnKNSInstrucContinue.Name = "btnKNSInstrucContinue"
        Me.btnKNSInstrucContinue.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSInstrucContinue.TabIndex = 11
        Me.btnKNSInstrucContinue.Text = "Continue"
        Me.btnKNSInstrucContinue.UseVisualStyleBackColor = False
        '
        'frmKNSInstructions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(37.0!, 65.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2660, 1227)
        Me.Controls.Add(Me.btnKNSInstrucBack)
        Me.Controls.Add(Me.btnKNSInstrucContinue)
        Me.Controls.Add(Me.lblKNSInstrucANEIS)
        Me.Controls.Add(Me.lblKNSInstrucOS)
        Me.Controls.Add(Me.lblKNSInstrucWS)
        Me.Controls.Add(Me.lblKNSInstructionsTitle)
        Me.Controls.Add(Me.Label1)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.Name = "frmKNSInstructions"
        Me.Text = "Instructions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblKNSInstructionsTitle As Label
    Friend WithEvents lblKNSInstrucWS As Label
    Friend WithEvents lblKNSInstrucOS As Label
    Friend WithEvents lblKNSInstrucANEIS As Label
    Friend WithEvents btnKNSInstrucBack As Button
    Friend WithEvents btnKNSInstrucContinue As Button
End Class
