﻿Public Class Parameters
    Public Shared Property ParameterList As New List(Of Parameters)

    Public Property Name As Long
    Public Property UM As String
    Public Property DemandP1 As Integer
    Public Property DemandP2 As Integer
    Public Property DemandP3 As Integer
    Public Property DemandP4 As Integer
    Public Property DemandP5 As Integer
    Public Property DemandP6 As Integer
    Public Property DemandP7 As Integer
    Public Property DemandP8 As Integer
    Public Property DemandP9 As Integer
    Public Property DemandP10 As Integer
    Public Property TotalDemand As Integer

End Class
