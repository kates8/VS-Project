﻿Public Class HoursPerShift
    Public Shared Property HoursPerShiftList As New List(Of HoursPerShift)

    Public Property ID As Long
    Public Property ShiftPeriod As String
    Public Property Units As String
    Public Property MW5A As Double
    Public Property MW11A As Double
    Public Property MW5P As Double
    Public Property TT5A As Double
    Public Property TT11A As Double
    Public Property TT5P As Double
    Public Property F5A As Double
    Public Property SS5A As Double
    Public Property SS11A As Double
    Public Property SS5P As Double
    Public Property TSH As Double




End Class
