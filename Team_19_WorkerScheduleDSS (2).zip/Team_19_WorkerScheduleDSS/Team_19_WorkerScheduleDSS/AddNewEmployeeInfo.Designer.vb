﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKNSAddNewEmploy
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKNSAddNewEmploy))
        Me.lblKNSANETitle = New System.Windows.Forms.Label()
        Me.lblKNSNewEmployName = New System.Windows.Forms.Label()
        Me.lblKNSMinHours = New System.Windows.Forms.Label()
        Me.lblKNSMaxHours = New System.Windows.Forms.Label()
        Me.lblKNSShifts = New System.Windows.Forms.Label()
        Me.tbxKNSNewEmployName = New System.Windows.Forms.TextBox()
        Me.tbxKNSMinHours = New System.Windows.Forms.TextBox()
        Me.tbxKNSMaxHours = New System.Windows.Forms.TextBox()
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox()
        Me.btnKNSANEAccept = New System.Windows.Forms.Button()
        Me.btnKNSANECancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblKNSANETitle
        '
        Me.lblKNSANETitle.AutoSize = True
        Me.lblKNSANETitle.Font = New System.Drawing.Font("Verdana", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSANETitle.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSANETitle.Location = New System.Drawing.Point(409, 66)
        Me.lblKNSANETitle.Name = "lblKNSANETitle"
        Me.lblKNSANETitle.Size = New System.Drawing.Size(1773, 116)
        Me.lblKNSANETitle.TabIndex = 0
        Me.lblKNSANETitle.Text = "Add New Employee Information"
        '
        'lblKNSNewEmployName
        '
        Me.lblKNSNewEmployName.AutoSize = True
        Me.lblKNSNewEmployName.BackColor = System.Drawing.Color.Black
        Me.lblKNSNewEmployName.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSNewEmployName.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSNewEmployName.Location = New System.Drawing.Point(474, 352)
        Me.lblKNSNewEmployName.Name = "lblKNSNewEmployName"
        Me.lblKNSNewEmployName.Size = New System.Drawing.Size(703, 65)
        Me.lblKNSNewEmployName.TabIndex = 1
        Me.lblKNSNewEmployName.Text = "Enter Employee Name:"
        '
        'lblKNSMinHours
        '
        Me.lblKNSMinHours.AutoSize = True
        Me.lblKNSMinHours.BackColor = System.Drawing.Color.Black
        Me.lblKNSMinHours.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSMinHours.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSMinHours.Location = New System.Drawing.Point(661, 510)
        Me.lblKNSMinHours.Name = "lblKNSMinHours"
        Me.lblKNSMinHours.Size = New System.Drawing.Size(516, 65)
        Me.lblKNSMinHours.TabIndex = 2
        Me.lblKNSMinHours.Text = "Minimum Hours:"
        '
        'lblKNSMaxHours
        '
        Me.lblKNSMaxHours.AutoSize = True
        Me.lblKNSMaxHours.BackColor = System.Drawing.Color.Black
        Me.lblKNSMaxHours.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSMaxHours.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSMaxHours.Location = New System.Drawing.Point(647, 678)
        Me.lblKNSMaxHours.Name = "lblKNSMaxHours"
        Me.lblKNSMaxHours.Size = New System.Drawing.Size(530, 65)
        Me.lblKNSMaxHours.TabIndex = 3
        Me.lblKNSMaxHours.Text = "Maximum Hours:"
        '
        'lblKNSShifts
        '
        Me.lblKNSShifts.AutoSize = True
        Me.lblKNSShifts.BackColor = System.Drawing.Color.Black
        Me.lblKNSShifts.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKNSShifts.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblKNSShifts.Location = New System.Drawing.Point(694, 832)
        Me.lblKNSShifts.Name = "lblKNSShifts"
        Me.lblKNSShifts.Size = New System.Drawing.Size(483, 65)
        Me.lblKNSShifts.TabIndex = 4
        Me.lblKNSShifts.Text = "Possible Shifts:"
        '
        'tbxKNSNewEmployName
        '
        Me.tbxKNSNewEmployName.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxKNSNewEmployName.Location = New System.Drawing.Point(1277, 352)
        Me.tbxKNSNewEmployName.Name = "tbxKNSNewEmployName"
        Me.tbxKNSNewEmployName.Size = New System.Drawing.Size(544, 60)
        Me.tbxKNSNewEmployName.TabIndex = 5
        '
        'tbxKNSMinHours
        '
        Me.tbxKNSMinHours.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxKNSMinHours.Location = New System.Drawing.Point(1277, 515)
        Me.tbxKNSMinHours.Name = "tbxKNSMinHours"
        Me.tbxKNSMinHours.Size = New System.Drawing.Size(544, 60)
        Me.tbxKNSMinHours.TabIndex = 6
        '
        'tbxKNSMaxHours
        '
        Me.tbxKNSMaxHours.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxKNSMaxHours.Location = New System.Drawing.Point(1277, 683)
        Me.tbxKNSMaxHours.Name = "tbxKNSMaxHours"
        Me.tbxKNSMaxHours.Size = New System.Drawing.Size(544, 60)
        Me.tbxKNSMaxHours.TabIndex = 7
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.Font = New System.Drawing.Font("Verdana", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Items.AddRange(New Object() {"Shift 1", "Shift 2", "Shift 3", "Shift 4", "Shift 5", "Shift 6", "Shift 7", "Shift 8"})
        Me.CheckedListBox1.Location = New System.Drawing.Point(1287, 832)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(534, 279)
        Me.CheckedListBox1.TabIndex = 8
        '
        'btnKNSANEAccept
        '
        Me.btnKNSANEAccept.BackColor = System.Drawing.Color.Black
        Me.btnKNSANEAccept.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSANEAccept.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSANEAccept.Location = New System.Drawing.Point(1985, 832)
        Me.btnKNSANEAccept.Name = "btnKNSANEAccept"
        Me.btnKNSANEAccept.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSANEAccept.TabIndex = 9
        Me.btnKNSANEAccept.Text = "Accept"
        Me.btnKNSANEAccept.UseVisualStyleBackColor = False
        '
        'btnKNSANECancel
        '
        Me.btnKNSANECancel.BackColor = System.Drawing.Color.Black
        Me.btnKNSANECancel.Font = New System.Drawing.Font("Verdana", 19.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKNSANECancel.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnKNSANECancel.Location = New System.Drawing.Point(1985, 615)
        Me.btnKNSANECancel.Name = "btnKNSANECancel"
        Me.btnKNSANECancel.Size = New System.Drawing.Size(404, 128)
        Me.btnKNSANECancel.TabIndex = 10
        Me.btnKNSANECancel.Text = "Cancel"
        Me.btnKNSANECancel.UseVisualStyleBackColor = False
        '
        'frmKNSAddNewEmploy
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(45.0!, 78.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaGreen
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(2462, 1205)
        Me.Controls.Add(Me.btnKNSANECancel)
        Me.Controls.Add(Me.btnKNSANEAccept)
        Me.Controls.Add(Me.CheckedListBox1)
        Me.Controls.Add(Me.tbxKNSMaxHours)
        Me.Controls.Add(Me.tbxKNSMinHours)
        Me.Controls.Add(Me.tbxKNSNewEmployName)
        Me.Controls.Add(Me.lblKNSShifts)
        Me.Controls.Add(Me.lblKNSMaxHours)
        Me.Controls.Add(Me.lblKNSMinHours)
        Me.Controls.Add(Me.lblKNSNewEmployName)
        Me.Controls.Add(Me.lblKNSANETitle)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Verdana", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(11, 9, 11, 9)
        Me.Name = "frmKNSAddNewEmploy"
        Me.Text = "Add New Employee Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblKNSANETitle As Label
    Friend WithEvents lblKNSNewEmployName As Label
    Friend WithEvents lblKNSMinHours As Label
    Friend WithEvents lblKNSMaxHours As Label
    Friend WithEvents lblKNSShifts As Label
    Friend WithEvents tbxKNSNewEmployName As TextBox
    Friend WithEvents tbxKNSMinHours As TextBox
    Friend WithEvents tbxKNSMaxHours As TextBox
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents btnKNSANEAccept As Button
    Friend WithEvents btnKNSANECancel As Button
End Class
