﻿Public Class PreferredSchedule
    Public Shared Property PreferredScheduleList As New List(Of PreferredSchedule)

    Public Property ID As Long
    Public Property Name As String
    Public Property MinHours As Double
    Public Property MaxHours As Double
    Public Property Shift1 As Integer
    Public Property Shift2 As Integer
    Public Property Shift3 As Integer
    Public Property Shift4 As Integer
    Public Property Shift5 As Integer
    Public Property Shift6 As Integer
    Public Property WageRate As Double

End Class
